from __future__ import annotations
from typing_extensions import override
import torch
from ..model.config import Config, no_default
from ..model.model import Model
from ..util.rope import RopeStyle
from ..modules import RMSNorm, Embedding, TransformerBlock, MLAttention, GatedMLP, Linear, BlockSparseMLP
from ..modules.attn import prepare_for_attn
from .glm4_moe_lite_mtp import Glm4MoeLiteMTPModel

# GLM-4.7-Flash: DeepSeek-V3-style body (plain MLA + sigmoid noaux_tc MoE, 64 routed + 1 shared,
# top-4) with a single dense layer (L0) and a 1-layer DeepSeek-style MTP head at L47. No DSA
# indexer. Standard (non-interleaved) RoPE over the 64-dim rope slice only.
# Reference implementation: transformers models/glm4_moe_lite.


class Glm4MoeLiteConfig(Config):
    arch_string = "Glm4MoeLiteForCausalLM"

    def __init__(
        self,
        directory: str,
        **kwargs,
    ):
        super().__init__(
            directory,
            {"text": Glm4MoeLiteModel, "mtp": Glm4MoeLiteMTPModel},
            **kwargs
        )

        # Latent attention params
        self.hidden_size = self.read_cfg(int, "hidden_size", no_default)
        self.num_q_heads = self.read_cfg(int, "num_attention_heads", no_default)
        self.q_lora_rank = self.read_cfg(int, "q_lora_rank", no_default)
        self.kv_lora_rank = self.read_cfg(int, "kv_lora_rank", no_default)
        self.qk_nope_head_dim = self.read_cfg(int, "qk_nope_head_dim", no_default)
        self.qk_rope_head_dim = self.read_cfg(int, "qk_rope_head_dim", no_default)
        self.v_head_dim = self.read_cfg(int, "v_head_dim", no_default)
        self.qk_head_dim = self.qk_nope_head_dim + self.qk_rope_head_dim
        # Reported head dim, for allocation and logging; the cache stores the latent instead
        self.head_dim = self.qk_head_dim

        # Layers (read early: needed for the mlp_layer_types derivation)
        self.num_hidden_layers = self.read_cfg(int, "num_hidden_layers", no_default)

        # MLP params
        self.assert_cfg(str, "hidden_act", "silu", True)
        self.intermediate_size = self.read_cfg(int, "intermediate_size", no_default)
        self.moe_intermediate_size = self.read_cfg(int, "moe_intermediate_size", no_default)
        self.num_shared_experts = self.read_cfg(int, "n_shared_experts", 1)
        self.num_experts = self.read_cfg(int, "n_routed_experts", no_default)
        self.num_experts_per_tok = self.read_cfg(int, "num_experts_per_tok", 8)
        self.routed_scaling_factor = self.read_cfg(float, "routed_scaling_factor", 1.0)
        first_k_dense = self.read_cfg(int, "first_k_dense_replace", 3)
        self.mlp_layer_types = self.read_cfg(
            list, "mlp_layer_types",
            ["dense" if idx < first_k_dense else "sparse" for idx in range(self.num_hidden_layers)]
        )
        assert all(t in ("dense", "sparse") for t in self.mlp_layer_types)
        self.n_group = self.read_cfg(int, "n_group", 1)
        self.topk_group = self.read_cfg(int, "topk_group", 1)
        assert self.n_group in (None, 1) and self.topk_group in (None, 1), \
            f"Group-limited expert routing (n_group = {self.n_group}, topk_group = " \
            f"{self.topk_group}) is not supported"
        self.assert_cfg(str, "topk_method", "noaux_tc", True)
        self.assert_cfg(bool, "norm_topk_prob", True, True)

        # Norms
        self.rms_norm_eps = self.read_cfg(float, "rms_norm_eps", no_default)

        # Layers
        self.tie_word_embeddings = self.read_cfg(bool, "tie_word_embeddings", False)

        # RoPE applies to the rope slice of the query and the single shared rope key only.
        # GLM-4.7-Flash uses interleaved RoPE: the reference's config sets rope_interleave=True
        # (default) and dispatches to apply_rotary_pos_emb_interleave, which rotates adjacent
        # (x0,x1),(x2,x3) pairs -- exllamav3's RopeStyle.GPTJ. (Not the half/NEOX style.)
        self.rope_settings = self.read_rope_settings_default(
            RopeStyle.GPTJ,
            override_head_dim = self.qk_rope_head_dim,
        )

        # rope_type is "default" (no YaRN), so the softmax scale is just the unabsorbed head dim
        self.sm_scale = self.qk_head_dim ** -0.5

        # MTP head (model.layers.{num_hidden_layers}, DeepSeek-V3 shape). The component only
        # exists when the checkpoint actually carries the tensors
        self.num_mtp_layers = self.read_cfg(int, "num_nextn_predict_layers", 0)
        mtp_key = f"model.layers.{self.num_hidden_layers}.eh_proj"
        if self.num_mtp_layers == 0 or not any(
            self.stc.has_tensor(f"{mtp_key}.{t}") for t in ("weight", "trellis")):
            del self.model_classes["mtp"]


class Glm4MoeLiteModel(Model):
    config_class = Glm4MoeLiteConfig

    def __init__(
        self,
        config: Glm4MoeLiteConfig,
        key_prefix: str = "model",
        **kwargs
    ):
        super().__init__(config, **kwargs)

        self.modules += [
            Embedding(
                config = config,
                key = f"{key_prefix}.embed_tokens",
                vocab_size = config.vocab_size,
                hidden_size = config.hidden_size,
            )
        ]

        self.first_block_idx = len(self.modules)

        self.modules += [
            TransformerBlock(
                config = config,
                key = f"{key_prefix}.layers.{idx}",
                layer_idx = idx,
                attn_norm = RMSNorm(
                    config = config,
                    key = f"{key_prefix}.layers.{idx}.input_layernorm",
                    rms_norm_eps = config.rms_norm_eps,
                ),
                attn = MLAttention(
                    config = config,
                    key = f"{key_prefix}.layers.{idx}.self_attn",
                    layer_idx = idx,
                    hidden_size = config.hidden_size,
                    num_q_heads = config.num_q_heads,
                    kv_lora_rank = config.kv_lora_rank,
                    qk_nope_head_dim = config.qk_nope_head_dim,
                    qk_rope_head_dim = config.qk_rope_head_dim,
                    v_head_dim = config.v_head_dim,
                    rope_settings = config.rope_settings,
                    q_lora_rank = config.q_lora_rank,
                    sm_scale = config.sm_scale,
                    rms_norm_eps = config.rms_norm_eps,
                    qmap = "block.attn",
                    out_dtype = torch.float,
                    select_hq_bits = 2,
                ),
                mlp_norm = RMSNorm(
                    config = config,
                    key = f"{key_prefix}.layers.{idx}.post_attention_layernorm",
                    rms_norm_eps = config.rms_norm_eps,
                ),
                mlp = (
                    GatedMLP(
                        config = config,
                        key = f"{key_prefix}.layers.{idx}.mlp",
                        hidden_size = config.hidden_size,
                        intermediate_size = config.intermediate_size,
                        key_up = "up_proj",
                        key_gate = "gate_proj",
                        key_down = "down_proj",
                        qmap = "block.mlp",
                        interm_dtype = torch.half,
                        out_dtype = torch.float,
                        select_hq_bits = 1,
                    )
                    if config.mlp_layer_types[idx] == "dense" else
                    BlockSparseMLP(
                        config = config,
                        key = f"{key_prefix}.layers.{idx}.mlp",
                        hidden_size = config.hidden_size,
                        intermediate_size = config.moe_intermediate_size,
                        num_experts = config.num_experts,
                        num_experts_per_tok = config.num_experts_per_tok,
                        key_up = "experts.{expert_idx}.up_proj",
                        key_gate = "experts.{expert_idx}.gate_proj",
                        key_down = "experts.{expert_idx}.down_proj",
                        key_routing_gate = "gate",
                        key_e_score_bias = "gate.e_score_correction_bias",
                        qmap = "block.mlp",
                        interm_dtype = torch.half,
                        out_dtype = torch.float,
                        router_type = "dots",
                        routed_scaling_factor = config.routed_scaling_factor,
                        n_group = config.n_group,
                        topk_group = config.topk_group,
                        shared_experts = GatedMLP(
                            config = config,
                            key = f"{key_prefix}.layers.{idx}.mlp.shared_experts",
                            hidden_size = config.hidden_size,
                            intermediate_size = config.moe_intermediate_size * config.num_shared_experts,
                            key_up = "up_proj",
                            key_gate = "gate_proj",
                            key_down = "down_proj",
                            qmap = "block.mlp",
                            interm_dtype = torch.half,
                            out_dtype = torch.float,
                            select_hq_bits = 2,
                        ) if config.num_shared_experts else None,
                    )
                )
            )
            for idx in range(config.num_hidden_layers)
        ]

        self.last_kv_module_idx = len(self.modules) - 1

        head_alt_key = None
        if config.tie_word_embeddings and not self.config.stc.has_tensor("lm_head"):
            head_alt_key = f"{key_prefix}.embed_tokens"

        self.modules += [
            RMSNorm(
                config = config,
                key = f"{key_prefix}.norm",
                rms_norm_eps = config.rms_norm_eps,
                out_dtype = torch.half,
            ),
            Linear(
                config = config,
                key = "lm_head",
                qbits_key = "head_bits",
                alt_key = head_alt_key,
                in_features = config.hidden_size,
                out_features = config.vocab_size,
                qmap = "block",
                caps = {"logits_output": True}
            )
        ]

        self.logit_layer_idx = len(self.modules) - 1

        # Activate all experts during H capture pass in quantization
        self.calibration_all_experts = True

        # MLA layers currently do not support TP because the latent cache cannot be split by head
        self.caps.update({"supports_tp": False})


    @override
    def prepare_inputs(self, input_ids: torch.Tensor, params: dict) -> torch.Tensor:
        input_ids = prepare_for_attn(input_ids, params)
        return input_ids


    @override
    def default_chat_prompt(self, prompt: str, system_prompt: str = None) -> str:
        p = "[gMASK]<sop>"
        if system_prompt:
            p += f"<|system|>\n{system_prompt}"
        p += f"<|user|>\n{prompt}"
        p += f"<|assistant|>\n"
        return p
