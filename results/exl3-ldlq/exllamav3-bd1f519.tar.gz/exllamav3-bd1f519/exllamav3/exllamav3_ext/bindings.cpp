#include <cuda_fp16.h>

#include <torch/extension.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "stloader.h"
#include "cuda_host.h"
#include "hadamard.h"

#include "norm.cuh"
#include "hgemm.cuh"
#include "turing/fa75.cuh"
#include "rope.cuh"
#include "activation.cuh"
#include "softcap.cuh"
#include "sparse_head.cuh"
#include "routing.cuh"
#include "gdn.cuh"
#include "add.cuh"
#include "dflash2.cuh"

#include "quant/quantize.cuh"
#include "quant/pack.cuh"
#include "quant/reconstruct.cuh"
#include "quant/hadamard.cuh"
#include "quant/exl3_gemm.cuh"
#include "quant/exl3_gemv.cuh"
#include "quant/exl3_gemv_int8.cuh"
#include "quant/frac.cuh"
#include "cpu/moe_mul1.h"
#include "cpu/moe_handoff.h"
#include "quant/exl3_kernel_map.cuh"
#include "quant/util.cuh"
#include "quant/exl3_devctx.cuh"
#include "quant/exl3_moe.cuh"
#include "quant/exl3_moe_coop.cuh"

#include "generator/strings.h"
#include "generator/staging.h"
#include "generator/sampling_basic.cuh"
#include "generator/sampling_extra.cuh"
#include "generator/gumbel.cuh"
#include "generator/sampling_fused.cuh"
#include "generator/rep_pen.cuh"
#include "generator/dry.cuh"
#include "moe_unswizzle.cuh"
#include "generator/cache.cuh"

#include "cache/q_cache.cuh"

#include "histogram.cuh"

#include "parallel/context.cuh"
#include "parallel/broadcast.cuh"
#include "parallel/barrier.cuh"
#include "parallel/gather.cuh"
#include "parallel/all_reduce.cuh"

#include "libtorch/gated_delta_net.h"
#include "libtorch/attention.h"
#include "libtorch/shared_kv_attention.h"
#include "libtorch/mla_attention.h"
#include "libtorch/linear.h"
#include "libtorch/gated_rmsnorm.h"
#include "libtorch/mlp.h"
#include "libtorch/blocksparse_mlp.h"
#include "libtorch/dsv4_compressor.h"
#include "libtorch/dsv4_attn.h"
#include "dsv4_compress.cuh"
#include "dsv4_pool_quant.cuh"
#include "dsa_topk.cuh"
#include "hc_mix.cuh"
#include "dequant_blocks.cuh"
#include "ple.cuh"
#include "ngram.cuh"

#include "attention.cuh"

#include "sam.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
    // Optional kernel families; Python checks these before taking a path that needs them. hgemm_f16acc is left
    // out of ROCm builds (util/cuda_flags.py, HIP_EXCLUDED_SOURCES) with its bindings below: it serves GeForce
    // parts, whose fp32-accumulate MMA runs at half rate, while RDNA's hgemm goes through the WMMA GEMM
#if defined(USE_ROCM)
    const bool cuda_only = false;
#else
    const bool cuda_only = true;
#endif
    m.attr("HAS_GR_MIX_TILED") = true;          // gr_mix_tiled, gr_mix_tiled_slices
    m.attr("HAS_DET_GEMM") = true;              // routing_gemm_det, det_quant_weight, det_math_test
    m.attr("HAS_HGEMM_F16ACC") = cuda_only;     // hgemm_f16acc, hgemm_f16acc_status
    m.attr("HAS_DFLASH2") = true;               // dflash2_dynconv, dflash2_selector_walk, dflash2_topk

    m.def("stloader_read", &stloader_read, "stloader_read");
    m.def("stloader_open_file", &stloader_open_file, "stloader_open_file");
    m.def("stloader_close_file", &stloader_close_file, "stloader_close_file");
    py::class_<TensorLoadJob>(m, "TensorLoadJob")
        .def(py::init<std::vector<uintptr_t>, size_t, size_t, uintptr_t, size_t, bool, bool, bool, int>());
    m.def("stloader_deferred_cpu", &stloader_deferred_cpu, py::arg("jobs"));
    m.def("stloader_deferred_cuda", &stloader_deferred_cuda, py::arg("jobs"), py::arg("max_chunk_size"));
    m.def("stloader_deferred_batch", &stloader_deferred_batch, py::arg("file_handles"), py::arg("loads"), py::arg("max_chunk_size"));

    m.def("cuda_host_register", &cuda_host_register, py::arg("ptr"), py::arg("nbytes"), py::arg("flags"));
    m.def("cuda_host_unregister", &cuda_host_unregister, py::arg("ptr"));
    m.def("cuda_host_get_device_pointer", &cuda_host_get_device_pointer, py::arg("ptr"));
    m.def("cuda_memcpy_async", &cuda_memcpy_async, py::arg("dst"), py::arg("src"), py::arg("nbytes"), py::arg("kind"));
    m.def("cuda_device_get_attribute", &cuda_device_get_attribute, py::arg("attr"), py::arg("device"));
    m.def("pinned_cuda_view", &pinned_cuda_view, py::arg("t"), py::arg("device"));

    m.def("rms_norm", &rms_norm, "rms_norm",
        py::arg("x"), py::arg("w"), py::arg("y"), py::arg("epsilon"),
        py::arg("constant_bias"), py::arg("constant_scale"), py::arg("span_heads"),
        py::arg("add_residual"), py::arg("w_groups") = 1);
    m.def("rms_norm_res_in", &rms_norm_res_in, "rms_norm_res_in");
    m.def("gated_rms_norm", &gated_rms_norm, "gated_rms_norm");
    m.def("softcap", &softcap, "softcap");
    m.def("sparse_head_argmax", &sparse_head_argmax, "sparse_head_argmax");

    m.def("routing_ds3_nogroup", &routing_ds3_nogroup, "routing_ds3_nogroup");
    m.def("routing_ds3_group", &routing_ds3_group, "routing_ds3_group");
    m.def("routing_gemv_f32", &routing_gemv_f32, "routing_gemv_f32");
    m.def("routing_ds3_nogroup_logits", &routing_ds3_nogroup_logits, "routing_ds3_nogroup_logits");
    m.def("routing_sel_norm", &routing_sel_norm, "routing_sel_norm");
    m.def("moe_split_map", &moe_split_map, "moe_split_map");
    m.def("moe_split_issue", &moe_split_issue, "moe_split_issue");
    m.def("moe_split_collect_add", &moe_split_collect_add, "moe_split_collect_add");
    m.def("dsv4_compress", &dsv4_compress, "dsv4_compress");
    m.def("dsv4_pool_quant_scatter", &dsv4_pool_quant_scatter, "dsv4_pool_quant_scatter");
    m.def("dsv4_ring_append", &dsv4_ring_append, "dsv4_ring_append");
    m.def("dsa_topk", &dsa_topk, "dsa_topk");
    m.def("dsa_topk_tile", &dsa_topk_tile, "dsa_topk_tile");
    m.def("dsa_topk_merge_tiles", &dsa_topk_merge_tiles, "dsa_topk_merge_tiles");
    m.def("hc_mix", &hc_mix, "hc_mix");
    m.def("hc_mix_carry", &hc_mix_carry, "hc_mix_carry");
    m.def("ple_gate", &ple_gate, "ple_gate");
    m.def("ple_forward_streams", &ple_forward_streams, "ple_forward_streams");
    m.def("ple_forward_streams_fused", &ple_forward_streams_fused, "ple_forward_streams_fused");
    m.def("ngram_hash_cpu", &ngram_hash_cpu, "ngram_hash_cpu");
    m.def("ngram_gather_cpu", &ngram_gather_cpu, "ngram_gather_cpu");
    m.def("ngram_dequant", &ngram_dequant, "ngram_dequant");
    m.def("hc_head", &hc_head, "hc_head");
    m.def("hc_mix_fused", &hc_mix_fused, "hc_mix_fused");
    m.def("dequant_blocks", &dequant_blocks, "dequant_blocks");
    m.def("hc_mix_num_chunks", &hc_mix_num_chunks, "hc_mix_num_chunks");
    m.def("hc_apply", &hc_apply, "hc_apply");
    m.def("gr_mix", &gr_mix, "gr_mix");
    m.def("gr_mix_tiled", &gr_mix_tiled, "gr_mix_tiled");
    m.def("gr_mix_tiled_slices", &gr_mix_tiled_slices, "gr_mix_tiled_slices");
    m.def("routing_std", &routing_std, "routing_std");
    m.def("routing_gemm_det", &routing_gemm_det, "routing_gemm_det");
    m.def("det_quant_weight", &det_quant_weight, "det_quant_weight");
    m.def("det_math_test", &det_math_test, "det_math_test");
    m.def("routing_std_logits", &routing_std_logits, "routing_std_logits");

    m.def("had_paley", &had_paley, "had_paley");
    m.def("had_paley2", &had_paley2, "had_paley2");

    m.def("pg_init_context", &pg_init_context, "pg_init_context");
    m.def("pg_broadcast", &pg_broadcast, "pg_broadcast");
    m.def("pg_broadcast_ll", &pg_broadcast_ll, "pg_broadcast_ll");
    m.def("pg_barrier", &pg_barrier, "pg_barrier");
    m.def("pg_gather", &pg_gather, "pg_gather");
    m.def("pg_gather_small", &pg_gather_small, "pg_gather_small");
    m.def("pg_all_reduce", &pg_all_reduce, "pg_all_reduce");
    m.def("pg_all_reduce_cpu", &pg_all_reduce_cpu, "pg_all_reduce_cpu");
    m.def("run_cpu_reduce_jobs", &run_cpu_reduce_jobs, "run_cpu_reduce_jobs");
    m.def("end_cpu_reduce_jobs", &end_cpu_reduce_jobs, "end_cpu_reduce_jobs");

    m.def("quantize_tiles", &quantize_tiles, "quantize_tiles");
    m.def("quantize_tiles_scratch", &quantize_tiles_scratch, "quantize_tiles_scratch");
    m.def("quantize_tiles_frac", &quantize_tiles_frac, "quantize_tiles_frac");
    m.def("test_distribution", &test_distribution, "test_distribution");
    m.def("decode", &decode, "decode");
    m.def("pack_trellis", &pack_trellis, "pack_trellis");
    m.def("unpack_trellis", &unpack_trellis, "unpack_trellis");
    m.def("pack_trellis_frac", &pack_trellis_frac, "pack_trellis_frac");
    m.def("unpack_trellis_frac", &unpack_trellis_frac, "unpack_trellis_frac");
    m.def("pack_signs", &pack_signs, "pack_signs");
    m.def("reconstruct", &reconstruct, "reconstruct");
    m.def("reconstruct_had_slice", &reconstruct_had_slice, "reconstruct_had_slice");
    m.def("reconstruct_had_batch", &reconstruct_had_batch, "reconstruct_had_batch");
    m.def("reconstruct_batch", &reconstruct_batch, "reconstruct_batch");
    m.def("reconstruct_slice", &reconstruct_slice, "reconstruct_slice");
    m.def("had_r_128", &had_r_128, "had_r_128");
    m.def("had_r_128_batch", &had_r_128_batch, "had_r_128_batch");
    m.def("exl3_gemm", &exl3_gemm, "exl3_gemm");
    m.def("exl3_gemv", &exl3_gemv, "exl3_gemv");
    m.def("exl3_gemm_num_kernel_shapes", &exl3_gemm_num_kernel_shapes, "exl3_gemm_num_kernel_shapes");
    m.def("exl3_gemm_shape_compat", &exl3_gemm_shape_compat, "exl3_gemm_shape_compat",
          py::arg("shape_idx"), py::arg("size_m"), py::arg("size_k"), py::arg("size_n"), py::arg("bits"), py::arg("half_k") = false);
    m.def("g_get_cc", &g_get_cc, "g_get_cc");
    m.def("g_get_num_sms", &g_get_num_sms, "g_get_num_sms");
    m.def("g_get_smem_max", &g_get_smem_max, "g_get_smem_max");
    m.def("exl3_gemv_int8_max_k", &exl3_gemv_int8_max_k, "exl3_gemv_int8_max_k");
    m.def("exl3_moe_cpu_make_layer", &exl3_moe_cpu_make_layer, "exl3_moe_cpu_make_layer");
    m.def("exl3_moe_cpu_free_layer", &exl3_moe_cpu_free_layer, "exl3_moe_cpu_free_layer");
    m.def("exl3_moe_cpu_forward", &exl3_moe_cpu_forward, "exl3_moe_cpu_forward",
          py::call_guard<py::gil_scoped_release>());
    m.def("exl3_moe_cpu_has_avx2", &exl3_moe_cpu_has_avx2, "exl3_moe_cpu_has_avx2");
    m.def("exl3_moe_flag_write", &exl3_moe_flag_write, "exl3_moe_flag_write");
    m.def("exl3_moe_flag_wait", &exl3_moe_flag_wait, "exl3_moe_flag_wait");
    m.def("exl3_moe_split_issue_fused", &exl3_moe_split_issue_fused, "exl3_moe_split_issue_fused");
    m.def("exl3_moe_split_collect_fused", &exl3_moe_split_collect_fused, "exl3_moe_split_collect_fused");
    m.def("moe_unswizzle_trellis", &moe_unswizzle_trellis, "moe_unswizzle_trellis",
          py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(),
          py::arg("group") = 0, py::arg("planar") = 0);
    m.def("exl3_moe_cpu_set_memops", &exl3_moe_cpu_set_memops, "exl3_moe_cpu_set_memops");
    m.def("exl3_moe_cpu_set_prof", &exl3_moe_cpu_set_prof, "exl3_moe_cpu_set_prof");
    m.def("exl3_moe_cpu_pool_stress", &exl3_moe_cpu_pool_stress, "exl3_moe_cpu_pool_stress");
    m.def("exl3_moe_cpu_core_order", &exl3_moe_cpu_core_order, "exl3_moe_cpu_core_order");
    m.def("exl3_moe_cpu_worker_run", &exl3_moe_cpu_worker_run, "exl3_moe_cpu_worker_run",
          py::call_guard<py::gil_scoped_release>());
    m.def("exl3_moe_cpu_has_avx512_bw", &exl3_moe_cpu_has_avx512_bw, "exl3_moe_cpu_has_avx512_bw");
    m.def("exl3_moe_cpu_has_avx512_vnni", &exl3_moe_cpu_has_avx512_vnni, "exl3_moe_cpu_has_avx512_vnni");
    m.def("exl3_moe_cpu_has_avx512_vbmi", &exl3_moe_cpu_has_avx512_vbmi, "exl3_moe_cpu_has_avx512_vbmi");
    m.def("exl3_moe_cpu_swizzle_group", &exl3_moe_cpu_swizzle_group, "exl3_moe_cpu_swizzle_group");
    m.def("exl3_moe_cpu_planar_layout", &exl3_moe_cpu_planar_layout, "exl3_moe_cpu_planar_layout");
    m.def("exl3_mgemm", &exl3_mgemm, "exl3_mgemm",
          py::arg("A"), py::arg("B"), py::arg("C"), py::arg("suh"), py::arg("A_had"), py::arg("svh"),
          py::arg("indices"), py::arg("weights"), py::arg("K"), py::arg("force_shape_idx"), py::arg("mcg"),
          py::arg("mul1"), py::arg("min_index"), py::arg("max_index"), py::arg("force_num_sms"),
          py::arg("num_tokens") = 1, py::arg("size_n_list") = py::none(), py::arg("c_ptrs") = py::none(),
          py::arg("n_stride_list") = py::none(), py::arg("had_src_list") = py::none(), py::arg("num_had_src") = 0);
    m.def("hgemm", &hgemm, "hgemm");
    m.def("hgemm_batched", &hgemm_batched, "hgemm_batched");
    m.def("hgemm_recon", &hgemm_recon, "hgemm_recon");
#if !defined(USE_ROCM)
    m.def("hgemm_f16acc", &hgemm_f16acc, "hgemm_f16acc");
    m.def("hgemm_f16acc_status", &hgemm_f16acc_status, "hgemm_f16acc_status");
    m.def("fa75_fwd", &fa75_fwd, "fa75_fwd");
    m.def("fa75_fwd_slice", &fa75_fwd_slice, "fa75_fwd_slice");
#endif
    m.def("rope", &rope, "rope");
    m.def("gen_mrope_pos_ids", &gen_mrope_pos_ids, "gen_mrope_pos_ids");
    m.def("silu_mul", &silu_mul, "silu_mul");
    m.def("silu_oai_mul", &silu_oai_mul, "silu_oai_mul");
    m.def("gelu_mul", &gelu_mul, "gelu_mul");
    m.def("relu2_mul", &relu2_mul, "relu2_mul");
    m.def("relu_mul", &relu_mul, "relu_mul");
    m.def("xielu", &xielu, "xielu");
    m.def("add_sigmoid_gate", &add_sigmoid_gate, "add_sigmoid_gate");
    m.def("mul_sigmoid_", &mul_sigmoid_, "mul_sigmoid_");
    m.def("deinterleave_qg", &deinterleave_qg, "deinterleave_qg");
    m.def("mul_sigmoid_broadcast_", &mul_sigmoid_broadcast_, "mul_sigmoid_broadcast_");
    m.def("mul_softplus_broadcast_", &mul_softplus_broadcast_, "mul_softplus_broadcast_");
    m.def("add_sigmoid_gate_proj", &add_sigmoid_gate_proj, "add_sigmoid_gate_proj");
    m.def("add", &add, "add");

    m.def("gated_delta_net_fused_op", &gated_delta_net_fused_op, "gated_delta_net_fused_op");
    m.def("gated_delta_net_fused_op_2", &gated_delta_net_fused_op_2, "gated_delta_net_fused_op_2");
    m.def("cuda_recurrent_gated_delta_rule", &cuda_recurrent_gated_delta_rule, "cuda_recurrent_gated_delta_rule",
          py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(),
          py::arg("slots"), py::arg("history"), py::arg("slots_in") = py::none());
    m.def("mamba2_dt_op", &mamba2_dt_op, "mamba2_dt_op");
    m.def("cuda_recurrent_mamba2", &cuda_recurrent_mamba2, "cuda_recurrent_mamba2",
          py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(),
          py::arg("slots"), py::arg("history"), py::arg("slots_in") = py::none());
    m.def("cuda_causal_conv1d_update", &cuda_causal_conv1d_update, "cuda_causal_conv1d_update",
          py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg("activation"), py::arg("history"),
          py::arg("incremental") = false);
    m.def("gdn_ba_gemv", &gdn_ba_gemv, "gdn_ba_gemv");
    m.def("gdn_lowrank_gemv_f", [](const at::Tensor& x, const at::Tensor& w_t, at::Tensor& y)
        { gdn_lowrank_gemv_f_gr(x, w_t, y, nullptr); }, "gdn_lowrank_gemv_f");
    m.def("kda_gate_op", [](const at::Tensor& qkv, const at::Tensor& b, const at::Tensor& f,
                            const at::Tensor& dt_bias, const at::Tensor& a_log,
                            at::Tensor& mixed_qkv, at::Tensor& beta, at::Tensor& g,
                            float lower_bound, float beta_scale)
        { kda_gate_op_gr(qkv, b, f, dt_bias, a_log, mixed_qkv, beta, g, lower_bound, beta_scale, nullptr); },
        "kda_gate_op");

    py::class_<ConvRewindJob>(m, "ConvRewindJob")
        .def(py::init<uintptr_t, uintptr_t, int, int, int>());
    py::class_<ScanReplayJob>(m, "ScanReplayJob")
        .def(py::init<uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t, uintptr_t, int, int>(),
             py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg(), py::arg("prefix"), py::arg("tstride") = 1);
    m.def("batched_conv_rewind", &batched_conv_rewind, py::arg("jobs"), py::arg("device_index"));
    m.def("batched_scan_replay", &batched_scan_replay, py::arg("jobs"), py::arg("device_index"), py::arg("kind"),
          py::arg("num_k_heads"), py::arg("num_v_heads"), py::arg("k_head_dim"), py::arg("v_head_dim"),
          py::arg("state_half") = false);

    m.def("argmax_sample", &argmax_sample, "argmax_sample");
    m.def("gumbel_sample", &gumbel_sample, "gumbel_sample");
    m.def("gumbel_noise_f16", &gumbel_noise_f16, "gumbel_noise_f16");
    m.def("gumbel_noise_f32", &gumbel_noise_f32, "gumbel_noise_f32");
    m.def("gumbel_noise_log", &gumbel_noise_log, "gumbel_noise_log");
    m.def("fused_sampler", &fused_sampler, "fused_sampler");
    m.def("apply_logit_bitmask", &apply_logit_bitmask, "apply_logit_bitmask");
    m.attr("FUSED_SAMPLER_MAX_BLOCKS") = FUSED_SAMPLER_MAX_BLOCKS;
    m.attr("FUSED_SAMPLER_HIST_STRIDE") = FUSED_SAMPLER_HIST_STRIDE;
    m.def("apply_rep_pens", &apply_rep_pens, "apply_rep_pens");
    m.def("dry_penalty", &dry_penalty, "dry_penalty");
    m.def("apply_pres_freq_pens", &apply_pres_freq_pens, "apply_pres_freq_pens");
    m.def("adaptivep_gumbel_noise_f32", &adaptivep_gumbel_noise_f32, "adaptivep_gumbel_noise_f32");

    m.def("dflash2_dynconv", &dflash2_dynconv, "dflash2_dynconv");
    m.def("dflash2_selector_walk", &dflash2_selector_walk, "dflash2_selector_walk");
    m.def("dflash2_topk", &dflash2_topk, "dflash2_topk");
    m.def("cache_rotate", &cache_rotate, "cache_rotate");
    m.def("dspark_write_rows", &dspark_write_rows, "dspark_write_rows");
    m.def("paged_kv_cache_update", &paged_kv_cache_update, "paged_kv_cache_update");

    m.def("partial_strings_match", &partial_strings_match, "partial_strings_match");
    m.def("generator_stage_decode", &generator_stage_decode, "generator_stage_decode");
    m.def("count_match_tensor", &count_match_tensor, "count_match_tensor");

    m.def("quant_cache_cont", &quant_cache_cont, "quant_cache_cont");
    m.def("dequant_cache_cont", &dequant_cache_cont, "dequant_cache_cont");
    m.def("quant_cache_paged", &quant_cache_paged, "quant_cache_paged");
    m.def("dequant_cache_paged", &dequant_cache_paged, "dequant_cache_paged");
    m.def("dequant_cache_paged_window", &dequant_cache_paged_window, "dequant_cache_paged_window");

    m.def("count_inf_nan", &count_inf_nan, "count_inf_nan");
    m.def("histogram", &histogram, "histogram");

    m.def("blocksparse_mlp_routing", &blocksparse_mlp_routing, "blocksparse_mlp_routing");
    m.def("exl3_moe_max_concurrency", &exl3_moe_max_concurrency, "exl3_moe_max_concurrency");
    m.def("exl3_moe", &exl3_moe, "exl3_moe");
    m.def("exl3_moe_gather", &exl3_moe_gather, "exl3_moe_gather");
    m.def("exl3_moe_coop", &exl3_moe_coop, "exl3_moe_coop");

    m.def("bighead_attn", &bighead_attn, "bighead_attn");
    m.def("bighead_attn_paged", &bighead_attn_paged, "bighead_attn_paged");
    m.def("bighead_attn_workspace_size", &bighead_attn_workspace_size, "bighead_attn_workspace_size");

    #include "libtorch/linear_bc.h"
    #include "libtorch/gated_delta_net_bc.h"
    #include "libtorch/attention_bc.h"
    #include "libtorch/shared_kv_attention_bc.h"
    #include "libtorch/mla_attention_bc.h"
    #include "libtorch/gated_rmsnorm_bc.h"
    #include "libtorch/mlp_bc.h"
    #include "libtorch/blocksparse_mlp_bc.h"
    #include "libtorch/dsv4_compressor_bc.h"
    #include "libtorch/dsv4_attn_bc.h"
    #include "sam_bc.h"
}
