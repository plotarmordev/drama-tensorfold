#include "moe_unswizzle.cuh"
#include <c10/cuda/CUDAGuard.h>
#include <ATen/cuda/CUDAContext.h>
#include "util.h"
#include "util.cuh"
#include "quant/bits_k.cuh"

// Expert weights offloaded to the CPU live in the arena in a packed trellis layout for the
// banded CPU kernels (exl3_moe_cpu_swizzle_group / exl3_moe_cpu_planar_layout): tile (kt, nt)
// at (nt / g) * tiles_k * g + kt * g + nt % g instead of kt * tiles_n + nt, and on the AVX2
// tier (g = 2) each integer tile's dwords planar-repacked (native dword w at
// 8 * (w % bits) + w / bits). Fractional tiles instead have Q = 2*bits+1 halfword planes:
// native halfword h is at 8 * ((h ^ 1) % Q) + (h ^ 1) / Q, without a byte swap.
// When experts stream back to the GPU for prefill they are staged and DMA'd verbatim, and this
// kernel restores the native order in VRAM, which is the only order the GEMM and reconstruct
// kernels read. Per (expert, kt, native 8-tile run) the run is one contiguous block in the
// native layout and g | 8/g contiguous sub-runs of g tiles in the packed one, so each block
// moves its run at VRAM bandwidth -- one read + one write, instead of tiles_k * groups
// scattered memcpys on the stager thread. group = 0 is a plain copy.

#define NUM_THREADS 128

// Q = 0 keeps the runtime layout; Q = 3/5/7 specializes fractional planar group 2.
template <int Q = 0>
__global__ __launch_bounds__(NUM_THREADS)
void moe_unswizzle_kernel
(
    const uint8_t* __restrict__ src,
    uint8_t* __restrict__ dst,
    const size_t expert_stride_b,
    const size_t proj_off_b,
    const int tiles_k,
    const int tiles_n,
    const int runtime_tile_b,
    const int runtime_group,      // 0 (native) | 2 | 8
    const int runtime_planar      // 1: also invert planar dwords or fractional halfwords
)
{
    const int tile_b = Q ? 16 * Q : runtime_tile_b;
    const int group = Q ? 2 : runtime_group;
    const int planar = Q ? 1 : runtime_planar;
    const int runs = tiles_n / 8;
    const int kt = blockIdx.x / runs;
    const int r = blockIdx.x % runs;            // native 8-tile run index
    const size_t base = (size_t) blockIdx.y * expert_stride_b + proj_off_b;
    const size_t run_off = base + ((size_t) kt * tiles_n + (size_t) r * 8) * tile_b;
    const size_t run_b = (size_t) 8 * tile_b;
    uint4* d = reinterpret_cast<uint4*>(dst + run_off);
    if (!group)
    {
        const uint4* s = reinterpret_cast<const uint4*>(src + run_off);
        for (int i = threadIdx.x; i < (int) (run_b / 16); i += NUM_THREADS)
            d[i] = s[i];
        return;
    }
    const size_t sub_b = (size_t) group * tile_b;
    for (int s = 0; s < 8 / group; ++s)
    {
        const size_t sub_src = base + ((size_t) (r * (8 / group) + s) * tiles_k + kt) * sub_b;
        uint4* sd = d + (size_t) s * (sub_b / 16);
        if (!planar)
        {
            const uint4* ss = reinterpret_cast<const uint4*>(src + sub_src);
            for (int i = threadIdx.x; i < (int) (sub_b / 16); i += NUM_THREADS)
                sd[i] = ss[i];
            continue;
        }
        if (tile_b % 32)
        {
            // Fractional planar inverse on dwords: native dword w holds halfwords 2w (low) and 2w + 1 (high),
            // and native halfword h sits at packed halfword 8 * ((h ^ 1) % Q) + (h ^ 1) / Q, so the low half
            // comes from chronological halfword 2w + 1 and the high half from 2w. Each source halfword is read
            // as the dword containing it and the two are merged with one byte permute: dword traffic only
            const int q = Q ? Q : tile_b / 16;
            const int wd = tile_b / 4;                  // dwords per tile (4 * q)
            const uint32_t* ss = reinterpret_cast<const uint32_t*>(src + sub_src);
            uint32_t* dd = reinterpret_cast<uint32_t*>(sd);
            for (int i = threadIdx.x; i < (int) (sub_b / 4); i += NUM_THREADS)
            {
                const int w = i % wd;
                const int tile0 = i - w;
                const int hl = 2 * w + 1, hh = 2 * w;
                const int pl = 8 * (hl % q) + hl / q;   // packed halfword holding the low half
                const int ph = 8 * (hh % q) + hh / q;   // ... and the high half
                const uint32_t a = ss[tile0 + (pl >> 1)];
                const uint32_t b = ss[tile0 + (ph >> 1)];
                const int sel = ((pl & 1) ? 0x0032 : 0x0010) | ((ph & 1) ? 0x7600 : 0x5400);
                dd[i] = __byte_perm(a, b, sel);
            }
            continue;
        }
        // Planar inverse: native dword w of a tile is stored at 8 * (w % bits) + w / bits
        // (integer rates only, tile_b = 32 * bits; per-dword traffic inside one tile)
        const int bits = tile_b / 32;
        const int wd = tile_b / 4;                      // dwords per tile
        const uint32_t* ss = reinterpret_cast<const uint32_t*>(src + sub_src);
        uint32_t* dd = reinterpret_cast<uint32_t*>(sd);
        for (int i = threadIdx.x; i < (int) (sub_b / 4); i += NUM_THREADS)
        {
            const int w = i % wd;
            dd[i] = ss[(i - w) + 8 * (w % bits) + w / bits];
        }
    }
}

void moe_unswizzle_trellis
(
    const at::Tensor& src,
    const at::Tensor& dst,
    int64_t num_experts,
    int64_t expert_stride_b,
    int64_t proj_off_b,
    int64_t tiles_k,
    int64_t tiles_n,
    double K,
    int64_t group,                // packed tile group of this projection (0/2/8)
    int64_t planar                // 1: planar dword / fractional halfword order to invert
)
{
    const at::cuda::OptionalCUDAGuard device_guard(src.device());
    cudaStream_t stream = at::cuda::getCurrentCUDAStream().stream();
    TORCH_CHECK(src.is_cuda() && dst.is_cuda() && src.device() == dst.device(), "moe_unswizzle: tensors must share a CUDA device");
    TORCH_CHECK(src.is_contiguous() && dst.is_contiguous(), "moe_unswizzle: tensors must be contiguous");
    TORCH_CHECK(tiles_n % 8 == 0, "moe_unswizzle: tiles_n must be a multiple of 8");
    TORCH_CHECK(group == 0 || group == 2 || group == 8, "moe_unswizzle: group must be 0, 2 or 8");
    TORCH_CHECK(planar == 0 || planar == 1, "moe_unswizzle: planar must be 0 or 1");
    TORCH_CHECK(!planar || group, "moe_unswizzle: planar requires a swizzled projection");
    TORCH_CHECK(num_experts >= 0 && tiles_k >= 0 && tiles_n >= 0 && expert_stride_b >= 0 && proj_off_b >= 0,
                "moe_unswizzle: negative size or offset");
    const BitsK bk = bits_from_K((float) K);
    const int tile_b = bk.bits * 32 + (bk.half ? 16 : 0);
    TORCH_CHECK(!planar || !bk.half || group == 2,
                "moe_unswizzle: fractional planar layout requires group 2");
    TORCH_CHECK((expert_stride_b | proj_off_b) % 16 == 0, "moe_unswizzle: offsets must be 16-byte aligned");

    // No experts or no tiles: nothing to copy
    if (!num_experts || !tiles_k || !tiles_n) return;

    const int64_t proj_b = tiles_k * tiles_n * tile_b;
    const int64_t need = (num_experts - 1) * expert_stride_b + proj_off_b + proj_b;
    TORCH_CHECK(need <= (int64_t) src.numel() * src.element_size()
                && need <= (int64_t) dst.numel() * dst.element_size(), "moe_unswizzle: batch exceeds the buffers");
    dim3 grid((unsigned) (tiles_k * (tiles_n / 8)), (unsigned) num_experts);
    auto kernel = moe_unswizzle_kernel<>;
    if (planar && bk.half)
    {
        if      (bk.bits == 1) kernel = moe_unswizzle_kernel<3>;
        else if (bk.bits == 2) kernel = moe_unswizzle_kernel<5>;
        else if (bk.bits == 3) kernel = moe_unswizzle_kernel<7>;
    }
    kernel<<<grid, NUM_THREADS, 0, stream>>>(
        (const uint8_t*) src.data_ptr(), (uint8_t*) dst.data_ptr(),
        (size_t) expert_stride_b, (size_t) proj_off_b, (int) tiles_k, (int) tiles_n, tile_b,
        (int) group, (int) planar);
    cuda_check(cudaPeekAtLastError());
}