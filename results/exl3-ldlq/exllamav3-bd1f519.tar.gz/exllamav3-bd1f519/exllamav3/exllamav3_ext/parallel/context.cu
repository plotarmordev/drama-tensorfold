#include <cstring>
#include <cuda_fp16.h>
#include "context.cuh"
#include <c10/cuda/CUDAGuard.h>
#include <ATen/cuda/CUDAContext.h>
#include "../util.h"
#include "../util.cuh"

void pg_init_context(uintptr_t ctx)
{
    PGContext* ctx_ptr = (PGContext*) ctx;

    ctx_ptr->sync_timeout = 0;
    memset(ctx_ptr->sync_timeout_name, 0, sizeof(ctx_ptr->sync_timeout_name));
    ctx_ptr->broadcast_ll_epoch = 1;

    for (int i = 0; i < MAX_DEVICES; ++i)
    {
        ctx_ptr->barrier_arrive[i] = 0;
        ctx_ptr->barrier_release[i] = 0;
        ctx_ptr->broadcast_stage_device[i] = 0;
        ctx_ptr->broadcast_ll_sequence_device[i] = 0;
        ctx_ptr->reduce_stage_produced[i] = 0;
        ctx_ptr->reduce_stage_consumed[i] = 0;
        ctx_ptr->gather_stage_produced[i] = 0;
        ctx_ptr->gather_stage_consumed[i] = 0;
        ctx_ptr->cpusum_stage_device[i * REDUCE_STAGE_STRIDE] = 0;
        ctx_ptr->cpusum_stage_recv[i * REDUCE_STAGE_STRIDE] = 0;
        for (int j = 0; j < CPUREDUCE_MB_BLOCKS; ++j)
        {
            ctx_ptr->cpusum_stage_device_mb[(i * CPUREDUCE_MB_BLOCKS + j) * REDUCE_STAGE_STRIDE] = 0;
            ctx_ptr->cpusum_stage_recv_mb[(i * CPUREDUCE_MB_BLOCKS + j) * REDUCE_STAGE_STRIDE] = 0;
        }
    }

    ctx_ptr->reduce_jobs_head = 0;
    ctx_ptr->reduce_jobs_tail = 0;
    ctx_ptr->cpusum_stage_cpu = 0;
}

void pg_check_timeout(uintptr_t ctx)
{
    PGContext* ctx_ptr = (PGContext*) ctx;
    if (ctx_ptr->sync_timeout)
    {
        #if defined(USE_ROCM)
            const char* name = ctx_ptr->sync_timeout_name;
            TORCH_CHECK(false, "Synchronization timeout in kernel: ",
                        name[0] ? name : "<unknown>");
        #else
            TORCH_CHECK(false, "Synchronization timeout");
        #endif
    }
}
