from __future__ import annotations
import importlib.machinery
import importlib.util
import torch
from torch.utils.cpp_extension import load
import os
import sys
from .util.arch_list import maybe_set_arch_list_env
from .util.cuda_flags import cuda_cflags, extension_sources, hip_include_flags, patch_hip_ninja_file_writer, use_rocm_sdk_devel

extension_name = "exllamav3_ext"
verbose = False  # Print wall of text when compiling
ext_debug = False  # Compile with debug options

# Determine if we're on Windows

windows = (os.name == "nt")

# Determine if extension is already installed or needs to be built

def is_precompiled_extension_available():
    spec = importlib.util.find_spec(extension_name)
    if not spec or not spec.origin or not spec.loader:
        return False
    return any(
        spec.origin.endswith(suffix)
        for suffix in importlib.machinery.EXTENSION_SUFFIXES
    )

if is_precompiled_extension_available():
    import exllamav3_ext
else:

    # Kludge to get compilation working on Windows

    if windows:

        def find_msvc():

            # Possible locations for MSVC, in order of preference

            program_files_x64 = os.environ.get("ProgramW6432", os.environ.get("ProgramFiles", r"C:\Program Files"))
            program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")

            msvc_dirs = \
            [
                a + "\\Microsoft Visual Studio\\" + b + "\\" + c + "\\VC\\Tools\\MSVC\\"
                for b in ["2022", "2019", "2017"]
                for a in [program_files_x64, program_files_x86]
                for c in ["BuildTools", "Community", "Professional", "Enterprise", "Preview"]
            ]

            for msvc_dir in msvc_dirs:
                if not os.path.exists(msvc_dir): continue

                # Prefer the latest version

                versions = sorted(os.listdir(msvc_dir), reverse = True)
                for version in versions:

                    compiler_dir = msvc_dir + version + "\\bin\\Hostx64\\x64"
                    if os.path.exists(compiler_dir) and os.path.exists(compiler_dir + "\\cl.exe"):
                        return compiler_dir

            # No path found

            return None

        import subprocess

        # Check if cl.exe is already in the path

        try:

            subprocess.check_output(["where", "/Q", "cl"])

        # If not, try to find an installation of Visual Studio and append the compiler dir to the path

        except subprocess.CalledProcessError as e:

            cl_path = find_msvc()
            if cl_path:
                if verbose:
                    print(" -- Injected compiler path:", cl_path)
                os.environ["path"] += ";" + cl_path
            else:
                print(" !! Unable to find cl.exe; compilation will probably fail", file = sys.stderr)

    # compiler flags

    extra_cflags = []
    extra_cuda_cflags = cuda_cflags(
        cuda_home = torch.utils.cpp_extension.CUDA_HOME,
        debug = ext_debug,
        hip = bool(torch.version.hip),
    )

    if windows:
        # TODO: preprocessor and lean_and_mean flags are needed for Windows cu132 build, verify that they don't break
        #       older cu128 builds
        # NOMINMAX: windows.h otherwise defines min/max function-like macros that break every
        # std::min/std::max call site parsed after it (WIN32_LEAN_AND_MEAN does not suppress them).
        # Defined globally so it holds regardless of include order in any TU (mirrors setup.py).
        extra_cflags += ["/Ox", "/Zc:preprocessor", "/DWIN32_LEAN_AND_MEAN", "/DNOMINMAX"]
        extra_cuda_cflags += ["-DWIN32_LEAN_AND_MEAN", "-DNOMINMAX", "-Xcompiler=/Zc:preprocessor"]
        if ext_debug:
            extra_cflags += ["/Zi"]
            extra_cuda_cflags += []
    elif torch.version.hip:
        # torch hands the C++ flags to hipcc as well, and -Ofast implies fast-math (see hip_cflags)
        extra_cflags += ["-O3"]
    else:
        extra_cflags += ["-Ofast"]
        extra_cuda_cflags += []
        if ext_debug:
            extra_cflags += ["-ftime-report", "-DTORCH_USE_CUDA_DSA"]
            extra_cuda_cflags += []

    # Windows: torch's JIT runs bare cl for the C++ sources and never passes -ccbin, so keep nvcc on the same cl.exe.
    # ROCm: CUDAHOSTCXX belongs to nvcc; hipcc takes no -ccbin
    if not windows and not torch.version.hip and (cuda_host_cxx := os.environ.get("CUDAHOSTCXX")):
        extra_cuda_cflags += ["-ccbin", cuda_host_cxx]
    elif windows and os.environ.get("CUDAHOSTCXX"):
        print(
            " !! CUDAHOSTCXX is not used by the JIT build on Windows; "
            "nvcc uses the same cl.exe as the C++ sources (see doc/env_vars.md)",
            file = sys.stderr
        )

    if verbose and not torch.version.hip:
        extra_cuda_cflags += ["--ptxas-options=-v"]

    # linker flags

    extra_ldflags = []

    if windows:
        extra_ldflags += ["cublas.lib"]
        if sys.base_prefix != sys.prefix:
            extra_ldflags += [f"/LIBPATH:{os.path.join(sys.base_prefix, 'libs')}"]
    elif torch.version.hip:
        # The ROCm extension calls hipBLAS directly (hgemm.cu, graph.cu)
        extra_ldflags += ["-lhipblas"]

    # sources

    library_dir = os.path.dirname(os.path.abspath(__file__))
    sources_dir = os.path.join(library_dir, extension_name)
    sources = extension_sources(sources_dir, hip = bool(torch.version.hip))
    if torch.version.hip:
        # With no target list, torch builds for every architecture it supports, wave64 ones included, which
        # the kernels cannot compile for. maybe_set_rocm_arch_env fills it in from the visible devices, so an
        # empty list here means HIP sees none (CUDA_VISIBLE_DEVICES is honored by HIP as well)
        if not os.environ.get("PYTORCH_ROCM_ARCH"):
            raise RuntimeError(
                "No ROCm device is visible to build the extension for. Check CUDA_VISIBLE_DEVICES and "
                "HIP_VISIBLE_DEVICES (HIP honors both), or set PYTORCH_ROCM_ARCH (e.g. gfx1100) explicitly."
            )
        use_rocm_sdk_devel(torch.utils.cpp_extension)
        extra_cflags += hip_include_flags(sources_dir)
        extra_cuda_cflags += hip_include_flags(sources_dir)
        # Flags hipcc would add from its environment go on the command line instead, where the ccache wrapper
        # (hip_compiler_wrapper) hashes them; left to hipcc, a changed define is a cache hit on the old object
        extra_cuda_cflags += os.environ.get("HIPCC_COMPILE_FLAGS_APPEND", "").split()

    # Load extension

    maybe_set_arch_list_env()
    if torch.version.hip:
        # Dependency files for the HIP compile rule (header edits rebuild their includers) and the
        # ccache/sccache wrapper torch applies to CUDA builds only
        patch_hip_ninja_file_writer(torch.utils.cpp_extension)
    try:
        exllamav3_ext = load(
            name = extension_name,
            sources = sources,
            extra_include_paths = [sources_dir],
            verbose = verbose,
            extra_ldflags = extra_ldflags,
            extra_cuda_cflags = extra_cuda_cflags,
            extra_cflags = extra_cflags
        )
    except IndexError as e:
        # With no list given (or "native"), torch derives the architectures from the visible GPUs and
        # fails with an IndexError when there are none
        if torch.version.cuda and os.environ.get("TORCH_CUDA_ARCH_LIST", "") in ("", "native") and \
                not torch.cuda.device_count():
            raise RuntimeError(
                f"No CUDA device is visible to determine the architectures to build {extension_name} for. "
                "Set TORCH_CUDA_ARCH_LIST to the target architectures, e.g. TORCH_CUDA_ARCH_LIST=\"8.6;8.9+PTX\""
            ) from e
        raise
