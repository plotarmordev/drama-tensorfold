from __future__ import annotations
from .generator import Generator
from .job import Job
import asyncio
import torch

# Sentinel pushed to an AsyncJob's queue on cancellation so a consumer parked in queue.get() wakes up and
# exits, rather than waiting forever for results that will no longer be produced
_CANCELLED_SENTINEL = object()

class AsyncGenerator:
    """
    Async wrapper for dynamic generator. See definition of Generator.
    """
    def __init__(self, *args, **kwargs):
        self.generator = Generator(*args, **kwargs)
        self.jobs = {}
        self.error = None
        self.condition = asyncio.Condition()
        self.iteration_task = asyncio.create_task(self._run_iteration())

    async def _run_iteration(self):
        try:
            while True:
                # Sleep while there is no async work registered. The condition releases its lock while waiting and
                # is notified by enqueue() or close(), so this background task does not spin between requests.
                async with self.condition:
                    # Wake when the first job arrives or when close() has cancelled the iteration task.
                    # While idle, continue the disk flush in steps (Generator.idle_work). Each step is short, so a
                    # new job waits for at most one step
                    while not (len(self.jobs) > 0 or self.iteration_task.cancelled()):
                        if self.generator.has_idle_work():
                            try:
                                await asyncio.wait_for(self.condition.wait(), timeout = 0.25)
                            except asyncio.TimeoutError:
                                pass
                            if not self.jobs:
                                self.generator.idle_work()
                        else:
                            await self.condition.wait()

                # Drive exactly one synchronous generator step and fan out any returned events to the owning
                # AsyncJob queues. Missing jobs can happen if a job was cancelled after iterate() started.
                # Delivery must never block: this single task serves every job, so waiting on one stalled
                # consumer (e.g. a disconnected client that stopped draining its queue) would wedge the whole
                # generator (issue #227).
                results = self.generator.iterate()
                self.deliver_results(results)

                # Yield back to the event loop so result consumers and cancellation requests can run between
                # generator iterations, even if the synchronous generator immediately has more work available.
                await asyncio.sleep(0)

        except asyncio.CancelledError:
            # Silently return on cancel
            return

        except Exception as e:
            # If the generator throws an exception it won't pertain to any one ongoing job, so push it to all of
            # them. The iteration task ends here and the generator is unusable, so record the error and deliver
            # it to any job enqueued later as well, instead of letting those jobs wait forever on a dead loop.
            self.error = e
            # The cache contents are not known to be correct now: the disk tier must not keep them
            disk = getattr(self.generator, "disk_page_cache", None)
            if disk is not None:
                disk.abort()
            for async_job in self.jobs.values():
                async_job.put_result(e)
            self.jobs.clear()

    def deliver_results(self, results):
        """
        Fan generator results out to the owning AsyncJob queues. Missing jobs can happen if a job
        was cancelled after iterate() started. Delivery must never block: this single task serves
        every job, so waiting on one stalled consumer would wedge the whole generator (issue #227).
        """
        for result in results:
            job = result["job"]
            async_job = self.jobs.get(job)
            if not async_job:
                continue
            if result.get("stage") == "error":
                # Per-job failure contained by Generator.reap_failed_job. The raw exception
                # must go into the queue as an exception object, not as a result dict:
                # __aiter__ re-raises queued exceptions, which the server surfaces as an
                # error for this request. A dict here would instead stream as a clean
                # (empty) completion.
                async_job.put_result(result["error"])
                del self.jobs[job]
                continue
            async_job.put_result(result)
            if result["eos"]:
                del self.jobs[job]

    def enqueue(self, job: AsyncJob):
        # The iteration task died on a generator exception; surface it to the new job's consumer immediately
        if self.error is not None:
            job.put_result(self.error)
            return

        # Track the AsyncJob before enqueueing the underlying Job so any immediate generator result has a queue to
        # land in. The sync generator still owns scheduling and serial assignment.
        assert job.job not in self.jobs
        self.jobs[job.job] = job
        try:
            self.generator.enqueue(job.job)
        except Exception:
            # A rejected job (e.g. too long for the cache) must not stay tracked: it would never produce a
            # result, and a non-empty job map keeps the iteration loop spinning instead of idling
            del self.jobs[job.job]
            raise

        # Condition.notify_all() must run while holding the condition lock, so schedule a tiny coroutine instead of
        # trying to notify directly from this synchronous method.
        asyncio.create_task(self._notify_condition())

    async def _notify_condition(self):
        async with self.condition:
            self.condition.notify_all()

    async def close(self):
        self.iteration_task.cancel()

        # Force a re-check of the condition to unlock the loop
        await self._notify_condition()
        try:
            await self.iteration_task
        except asyncio.CancelledError:
            pass

        # Wake any consumers still parked on job queues; no more results will be produced
        for async_job in self.jobs.values():
            async_job.put_result(_CANCELLED_SENTINEL)
        self.jobs.clear()

        # Release what the sync generator holds on the host (recurrent checkpoints, the CPU page cache
        # tier, pinned buffers) now: the failed jobs and their tracebacks can keep it reachable for a while
        self.generator.close()

    async def cancel(self, job: AsyncJob):
        # Remove the underlying Job from the synchronous generator first so no new tokens are produced, then drop
        # the async mapping so any late results from an in-flight iteration are ignored. Finally wake the job's
        # consumer in case it is parked in queue.get(), waiting for a result that will never arrive.
        # After a generator exception the sync generator's state is suspect and every job was already delivered
        # the error; don't poke it from consumers' cleanup handlers, or their except/finally blocks can be hit
        # with a second exception.
        if self.error is None:
            self.generator.cancel(job.job)
        if job.job not in self.jobs:
            return
        del self.jobs[job.job]
        job.put_result(_CANCELLED_SENTINEL)


class AsyncJob:
    """
    Async wrapper for dynamic generator job. See definition of Job.
    """
    def __init__(self, generator: AsyncGenerator, *args: object, **kwargs: object):
        self.generator = generator
        self.job = Job(*args, **kwargs)
        # The queue is unbounded and written with put_nowait: the shared iteration task must never block on a
        # consumer that stopped draining (see _run_iteration). Growth is paced by the sync generator's own token
        # rate and ends when the job completes or is cancelled, which is the frontend's responsibility on client
        # disconnect.
        self.queue = asyncio.Queue()
        self.generator.enqueue(self)
        self.cancelled = False

    def put_result(self, result):
        self.queue.put_nowait(result)

    async def __aiter__(self):
        while True:
            # cancel() sets this flag after removing the job from the generator; the iterator exits cleanly instead
            # of waiting forever for an EOS event that will no longer be produced.
            if self.cancelled:
                break

            # Results are pushed by AsyncGenerator._run_iteration(). Exceptions are broadcast to all queues if the
            # shared generator loop fails, so consuming code sees the error at the await point. The sentinel wakes
            # this iterator when the job is cancelled from another task while parked here.
            result = await self.queue.get()
            if result is _CANCELLED_SENTINEL:
                break
            if isinstance(result, Exception):
                raise result
            yield result
            if result["eos"]:
                break

    def constrain_output_now(self, output: str | torch.Tensor):
        """
        Inject a fixed token string into the job's output stream; see Job.constrain_output_now. Safe to
        call from any coroutine on the generator's event loop. Note that tokens already sampled by the
        shared iteration task but still queued for this consumer precede the injection in the stream.
        """
        self.job.constrain_output_now(output)

    def set_sampler(self, sampler):
        """
        Replace the sampler mid-generation; see Job.set_sampler. Safe to call from any coroutine on the
        generator's event loop, including the body of an `async for` over this job. Results already queued
        for this consumer were sampled before the change.
        """
        self.job.set_sampler(sampler)

    def set_filters(self, filters):
        """
        Replace the filters mid-generation; see Job.set_filters and set_sampler above.
        """
        self.job.set_filters(filters)

    def set_banned_strings(self, banned_strings):
        """
        Replace the banned strings mid-generation; see Job.set_banned_strings and set_sampler above.
        """
        self.job.set_banned_strings(banned_strings)

    async def cancel(self):
        # Delegate cancellation to the wrapper so it can update both the sync generator queue and the async job map,
        # then mark this iterator as closed for any current or future consumers.
        await self.generator.cancel(self)
        self.cancelled = True
