from __future__ import annotations
import torch
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .generator import Generator
from ..constants import PAGE_SIZE
import numpy as np
from .pagetable import Sequence, tensor_hash_checksum, random_hash
from .filter import Filter
import random
import time
from ..ext import exllamav3_ext as ext
from .loop_detect import LoopDetector
from .sampler import Sampler, DefaultSampler
from ..util.tensor import SeqTensor
from ..tokenizer import MMEmbedding
from functools import lru_cache
from ..util import profile_opt


class NonFiniteLogits(RuntimeError):
    """A decode step produced NaN/Inf logits. Almost always a kernel bug (e.g. a miscompiled
    Triton specialization) rather than bad inputs; the message lists the toggles that A/B the
    fused decode paths to bisect with."""


# Convert list of strings to UTF32 format to pass by reference to partial matching function
@lru_cache(100)
def _strings_to_utf32(strings: tuple[str]) -> tuple[np.ndarray, np.ndarray] | None:
    # An empty string occupies no range in the packed buffer, and the matcher has no terminator to
    # stop it at: it would scan off the end of the buffer and can report a partial match that never
    # resolves, holding output indefinitely. An empty needle cannot match anything meaningful in
    # any case, so drop it here, where every caller passes through
    strings = tuple(s for s in strings if s)
    if not strings: return bytearray(), None

    encoded_strings = [s.encode("utf-32-le") for s in strings]
    encoded_lengths = [len(s) for s in encoded_strings]
    offsets = [0] + encoded_lengths
    for i in range(1, len(offsets)):
        offsets[i] += offsets[i - 1]
    total_length = offsets[-1]
    concat_strings = bytearray(total_length)
    for s, offset in zip(encoded_strings, offsets[:-1]):
        concat_strings[offset:offset + len(s)] = s

    concat_strings = np.frombuffer(concat_strings, dtype = np.uint8)
    offsets = np.frombuffer(np.array(offsets, dtype = np.int32), dtype = np.uint8)
    return concat_strings, offsets


class Job:

    def __init__(
        self,
        input_ids: torch.Tensor | list[torch.Tensor],
        max_new_tokens: int | None = None,
        min_new_tokens: int = 0,
        max_skips: int | None = 4,
        sampler: Sampler | None = None,
        seed: int = None,
        stop_conditions: list | tuple | set | None = None,
        decode_special_tokens: bool = False,
        return_top_tokens: int = 0,
        return_logits: bool = False,
        return_probs: bool = False,
        filters: list[Filter] | None = None,
        token_healing: bool = False,
        identifier: object | None = None,
        banned_strings: list[str] | None = None,
        embeddings: list[MMEmbedding] | None = None,
        max_rq_tokens: int | None = None,
        stop_on_loop: bool | dict | tuple = False,
        rq_state: dict | None = None,
        **kwargs
    ):
        """
        Create new job.

        :param input_ids:
            Tokenized IDs of the input prompt, shape (1, n) (a single-element list is also accepted). A job holds
            exactly one sequence

        :param max_new_tokens:
            Max no. output tokens to allow. None (default): no limit other than the cache capacity

        :param min_new_tokens:
            Minimum number of tokens to generate before stop tokens become active. Until this number have been
            sampled, stop tokens are suppressed but stop strings will still end response. May produce garbage output.

        :param max_skips:
            In the event that the job is too large to fit in the cache at any given moment but there are
            smaller jobs pending that would fit, those smaller jobs are started instead. This number
            specifies the maximum number of times a job can be skipped over in favor of a smaller job before it
            stalls the queue. After this, the job is guaranteed to be the next job started.

        :param sampler:
            Sampler

        :param seed:
            RNG seed (determinism is not guaranteed)

        :param stop_conditions:
            List of strings and/or token IDs that will trigger the EOS condition. If a stop condition is
            encountered it is not emitted as output. If the beginning of a stop string is sampled, stream output
            will be held until the stop condition can be resolved.

        :param decode_special_tokens:
            If True, special tokens like <|im_start|> etc. will be decoded and included in the text output.
            If False, special tokens will still be respected as stop conditions.

        :param return_top_tokens:
            Number of top tokens to return, along with their final sampling probabilities. There is some
            performance penalty for enabling this.

        :param return_logits:
            Return pre-sampling logits along with output tokens.

        :param return_probs:
            Return final sampling probability for each chosen token.

        :param filters:
            List of Filters to apply during generation.

        :param token_healing:
            Resample the last token of the input with a prefix constraint. E.g. if the last token is
            "_Hel", it is removed from the input and the first token of the output will be constrained to
            one of "_Hello", "_Help", "_Helium", etc. Only the added part of the healed token is emitted as
            text, i.e. "lo", "p", "ium" etc.

        :param identifier:
            Arbitrary object to return with every stream event relating to this job, e.g. an index to identify the
            output as belonging to a specific position in a batch

        :param embeddings:
            Optional list of MMEmbeddings to use, or list of lists for batched generation

        :param max_rq_tokens:
            Maximum number of tokens before job is requeued. Rounded to nearest page boundary. This limits how
            many new pages are allocated in the cache for the job in any one round and allows a single job to use
            the full cache size without limiting concurrency for other jobs.

        :param stop_on_loop:
            End generation (eos_reason "loop_detected") when the output settles into repeating the same text, exactly
            or nearly, with nothing else happening in between. True enables it with the default LoopDetector settings,
            a dict passes LoopDetector keyword arguments. The legacy (window_size, min_reps) tuple is accepted and
            treated as True; the detector has no fixed window. See generator/loop_detect.py for what is detected.

        :param rq_state:
            Internal, passed when job requeues itself

        :param kwargs:
        """

        assert all(ids.device.type == "cpu" for ids in input_ids), \
            "input_ids must reside in system memory"

        if rq_state is None:
            rq_state = {}
            self.is_requeued = False
            self.rq_new_tokens = 0
        else:
            self.is_requeued = True
            self.rq_new_tokens = rq_state["rq_new_tokens"]

        self.generator = None
        self.pagetable = None
        self.serial_number = None
        self.identifier = identifier

        self.max_skips = max_skips
        self.skips = 0
        self.all_unique_hashes = None

        # Default sampler settings
        if sampler is None:
            sampler = DefaultSampler()

        # Forced output injection (constrain_output_now). forced_ids holds tokens not yet sampled,
        # forced_index the queue position, forced_sample marks the token currently in flight between
        # receive_logits and receive_sample as forced. Suspended filters stay disabled for the
        # remainder of the job (including requeues) since their state machines cannot track
        # injected tokens.
        self.forced_ids = rq_state.get("forced_ids")
        self.forced_index = 0
        self.forced_ids_device = None
        self.forced_sample = False
        self.filters_suspended = rq_state.get("filters_suspended", False)

        # Sampling state
        self.held_text = rq_state.get("held_text", "")
        self.held_tokens = rq_state.get("held_tokens")
        self.held_k_tokens = rq_state.get("held_k_tokens")
        self.held_k_probs = rq_state.get("held_k_probs")
        self.held_probs = rq_state.get("held_probs")
        self.held_logits = rq_state.get("held_logits")
        self.full_completion = rq_state.get("full_completion", "")
        self.seed = seed

        # Prepare sequences
        if not isinstance(input_ids, list):
            input_ids = [input_ids]

        if token_healing and all(ids.shape[-1] > 1 for ids in input_ids):
            input_seq_ids = [ids[:, :-1] for ids in input_ids]
            self.prefix_token = torch.cat([ids[:, -1:] for ids in input_ids], dim = 0)
        else:
            input_seq_ids = input_ids
            self.prefix_token = None

        self.sequences = []
        for ids, seq_ids in zip(input_ids, input_seq_ids):
            assert ids.shape[-1] > 0, \
                "Input IDs cannot be empty."
            assert ids.shape[0] == 1, \
                "input_ids must be [1, seq_len] tensor or list of [1, seq_len] tensors"
            seq = Sequence(ids, seq_ids)
            self.sequences.append(seq)
        assert len(self.sequences) == 1, \
            "A job holds exactly one sequence (multi-sequence jobs are not supported)"

        # Generation parameters
        assert max_new_tokens is None or max_new_tokens >= 1, "max_new_tokens must be >= 1, or None for no limit"
        # None: no limit beyond what the cache can hold; resolved against the generator in prepare_for_queue
        self.max_new_tokens = max_new_tokens
        self.min_new_tokens = min_new_tokens
        self.new_tokens = 0 if self.prefix_token is None else -1
        self.sampler = sampler
        self.rng = rq_state.get("rng")
        if self.rng is None:
            self.rng = random.Random() if seed is None else random.Random(seed)
        self.orig_max_rq_tokens = max_rq_tokens
        self.max_rq_tokens = max_rq_tokens

        # Output options
        self.decode_special_tokens = decode_special_tokens
        self.return_top_tokens = return_top_tokens
        self.return_logits = return_logits
        self.return_probs = return_probs

        # Stop conditions
        self.stop_strings = rq_state.get("stop_strings", set())
        self.stop_tokens = rq_state.get("stop_tokens", set())
        if stop_conditions is not None:
            if isinstance(stop_conditions, str) or isinstance(stop_conditions, int):
                stop_conditions = [stop_conditions]
            for t in stop_conditions:
                if isinstance(t, int):
                    self.stop_tokens.add(t)
                elif isinstance(t, str):
                    self.stop_strings.add(t)
                else:
                    raise ValueError("Unsupported type in stop_conditions")
            self.stop_strings_utf32_buffer, self.stop_strings_utf32_offsets = \
                _strings_to_utf32(tuple(list(self.stop_strings)))
        else:
            self.stop_strings_utf32_buffer = rq_state.get("stop_strings_utf32_buffer")
            self.stop_strings_utf32_offsets = rq_state.get("stop_strings_utf32_offsets")

        self.stop_tokens_list = list(self.stop_tokens)
        self.stop_strings_list = list(self.stop_strings)
        self.stop_string_max_length = max([0] + [len(x) for x in self.stop_strings_list])

        # Banned strings
        self._init_banned_strings(banned_strings)

        self.checkpoint = None
        self.checkpoint_rewound = False

        # Metrics
        self.time_enqueue = None
        self.time_first_prefill = None
        self.time_first_token = None
        self.time_last_token = None
        self.time_enqueued = rq_state.get("time_enqueued", 0.0)
        self.time_prefill = rq_state.get("time_prefill", 0.0)
        self.time_generate = rq_state.get("time_generate", 0.0)
        self.accepted_draft_tokens = rq_state.get("accepted_draft_tokens", 0)
        self.rejected_draft_tokens = rq_state.get("rejected_draft_tokens", 0)
        self.rq_prompt_tokens = rq_state.get("prompt_tokens")
        self.rq_cached = rq_state.get("cached")
        self.draft_stats = []
        self.sparse_head_seeded = False
        self.cached_pages = 0
        self.cached_tokens = 0
        self.is_finished = False
        self.non_sequential_pages = 0
        self.total_pages = 0

        # Filters
        self.filters = filters if filters is not None else []
        self.filter_futures = []
        self.logit_masks = []
        self.pinned_logit_mask = None
        self.pinned_logit_bitmask = None
        self.device_logit_mask = None
        self.logits_device = None

        # Embeddings
        self.embeddings = embeddings or []
        self.alt_rope_freqs = None
        self.alt_rope_offset = 0

        # Pinned buffer for IDs during sampling, and its device-resident copy for the current step
        self.current_pinned_ids = None
        self.pinned_ids = None  # Lazy alloc
        self.current_device_ids = None
        self.pinned_ids_valid = 0  # Leading tokens of pinned_ids known to match sequence_ids

        # Recurrent state
        self.recurrent_state = None
        self.last_recurrent_checkpoint_pos = None

        # Loop detector. A requeued job continues the detector of its first pass (whose input is the original
        # prompt, so it is primed only there)
        self.stop_on_loop = stop_on_loop
        self.loop_detector = rq_state.get("loop_detector")
        if stop_on_loop and self.loop_detector is None:
            self.loop_detector = LoopDetector(**stop_on_loop) if isinstance(stop_on_loop, dict) else LoopDetector()
            self.loop_detector.prime(self.sequences[0].input_ids.torch())

        # N-gram automaton
        self.sam = rq_state.get("sam", None)
        self.sam_match = None

        # MTP state
        self.mtp_last_hidden = None


    def get_pinned_logit_mask(self):
        if self.pinned_logit_mask is None:
            self.pinned_logit_mask = torch.empty(
                (1, self.generator.padded_vocab_size),
                dtype = torch.half,
                device = "cpu",
                pin_memory = True
            )
        return self.pinned_logit_mask


    def get_pinned_logit_bitmask(self):
        # padded_vocab_size is a multiple of 32, so the packed mask width is exact
        if self.pinned_logit_bitmask is None:
            self.pinned_logit_bitmask = torch.empty(
                (1, self.generator.padded_vocab_size // 32),
                dtype = torch.int32,
                device = "cpu",
                pin_memory = True
            )
        return self.pinned_logit_bitmask


    def _expand_bitmask(self, bitmask: torch.Tensor) -> torch.Tensor:
        # Expand a packed int32 bitmask to a dense additive half mask, for combining with dense
        # masks from other filters on the same job
        bits = np.unpackbits(bitmask.view(-1).numpy().view(np.uint8), bitorder = "little")
        n = min(bits.shape[-1], self.generator.padded_vocab_size)
        mask = torch.full((1, self.generator.padded_vocab_size), float("-inf"), dtype = torch.half)
        mask[0, :n][torch.from_numpy(bits[:n]).bool()] = 0.0
        return mask


    def __repr__(self):
        if self.serial_number is None:
            return "Generator job (new)"
        else:
            return f"Generator job #{self.serial_number}"


    def is_prefill_done(self):
        return all(seq.kv_position == len(seq.sequence_ids) - 1 for seq in self.sequences)


    def get_max_seq_len(self):
        if not self.is_prefill_done():
            return 0
        max_seq_len = 0
        for seq in self.sequences:
            if seq.kv_position == len(seq.sequence_ids) - 1:
                max_seq_len = max(max_seq_len, len(seq.sequence_ids))
        return max_seq_len


    def get_input_ids_list(
        self,
        draft_tokens: torch.Tensor | None = None,
        idx: int = 0,
        add_to_cache: bool = False
    ):
        input_ids_list = []
        for seq in self.sequences:
            ids = seq.sequence_ids.torch_slice(seq.kv_position, None)
            if draft_tokens is not None:
                ids = torch.cat((ids, draft_tokens[idx:idx + 1, :]), dim = -1)
            input_ids_list.append(ids)
            if add_to_cache:
                tokens_to_add = ids.shape[-1]
                skvp = seq.kv_position
                while tokens_to_add:
                    page = seq.allocated_pages[skvp // PAGE_SIZE]
                    assert page.ref_count == 1
                    tokens_page = min(tokens_to_add, PAGE_SIZE - page.kv_position)
                    page.sequence[:, page.kv_position:page.kv_position + tokens_page] = ids[:, :tokens_page]
                    page.kv_position += tokens_page
                    skvp += tokens_page
                    ids = ids[:, tokens_page:]
                    tokens_to_add -= tokens_page
                    page.can_revert = False
        return input_ids_list


    def prepare_logit_mask(self):

        logit_mask = None
        healing = self.prefix_token is not None and self.new_tokens == -1

        # Finish filters and compile logit mask, but delay to avoid conflict with token healing.
        # Filter masks are either dense additive half tensors or packed int32 bitmasks (32
        # tokens per word, bit clear = masked out). An all-bitmask set stays packed all the way
        # to the sampling kernels; a bitmask is only expanded when it has to combine with a
        # dense mask from another filter.
        if not healing:
            f_idx = 0
            f_masks = []
            for f in self.filters:
                if not f.is_active:
                    continue
                if f.use_background_worker():
                    f_masks.append(self.filter_futures[f_idx].result())
                else:
                    f_masks.append(self.logit_masks[f_idx])
                f_idx += 1
            self.filter_futures.clear()
            self.logit_masks.clear()

            all_bits = all(m.dtype == torch.int32 for m in f_masks)
            if f_masks and all_bits:
                logit_mask = self.get_pinned_logit_bitmask()
                for i, m in enumerate(f_masks):
                    w = min(m.shape[-1], logit_mask.shape[-1])
                    if i == 0:
                        logit_mask[:, :w].copy_(m[:, :w])
                    else:
                        logit_mask[:, :w] &= m[:, :w]
                    # Tokens beyond a narrower mask count as masked out, matching the -inf
                    # padding semantics of the dense path
                    logit_mask[:, w:] = 0
            else:
                for m in f_masks:
                    if m.dtype == torch.int32:
                        m = self._expand_bitmask(m)
                    if logit_mask is None:
                        logit_mask = self.get_pinned_logit_mask()
                        logit_mask.copy_(m)
                    else:
                        logit_mask += m

        # Add individually blocked tokens to mask
        blocked_tokens = []
        if self.checkpoint and self.checkpoint["offset"] == 0:
            blocked_tokens += self.checkpoint["explored_tokens"]
        if self.new_tokens < self.min_new_tokens:
            blocked_tokens = blocked_tokens + self.stop_tokens_list
        if blocked_tokens:
            if logit_mask is None:
                logit_mask = self.get_pinned_logit_mask()
                logit_mask.zero_()
            if logit_mask.dtype == torch.int32:
                bits = logit_mask.view(-1).numpy().view(np.uint32)
                for t in blocked_tokens:
                    bits[t >> 5] &= ~np.uint32(1 << (t & 31))
            else:
                logit_mask[:, blocked_tokens] = float("-inf")

        # Mask out all but allowed tokens (token healing)
        allowed_tokens = []
        if healing:
            allowed_tokens += self.generator.tokenizer.get_tokens_with_prefix_id(self.prefix_token)
        if allowed_tokens:
            if logit_mask is None:
                logit_mask = self.get_pinned_logit_mask()
                logit_mask.fill_(float("-inf"))
                logit_mask[:, allowed_tokens] = 0
            else:
                inv_mask = torch.full_like(logit_mask, float("-inf"))
                inv_mask[:, allowed_tokens] = 0
                logit_mask += inv_mask

        # If any logits need masking, move mask to device.
        if logit_mask is not None:
            # logit_mask references the pinned host buffer for this job, which is correctly filled in at this point
            # Copy on the default stream so subsequent sampling blocks until mask is copied to device memory
            self.device_logit_mask = logit_mask.to(self.logits_device, non_blocking = True)
        else:
            self.device_logit_mask = None


    def constrain_output_now(self, output: str | torch.Tensor):
        """
        Inject a fixed token string into the job's output stream: the next samples are constrained to
        the given tokens, one per generation step, after which sampling continues unconstrained. The
        injected tokens pass through the regular generation pipeline, with these exceptions:

        - All filters on the job are permanently disabled: their state machines cannot accept or track
          arbitrary injected tokens, so they cannot be meaningfully resumed afterwards.
        - Any held banned-string checkpoint is released (text held back by a partial match is emitted),
          and banned-string matching is suspended until the last injected token has been processed.

        Stop conditions, max_new_tokens and the loop detector still apply, so an injected token that is
        a stop token, or injected text that completes a stop string, ends the job with the remaining
        injected tokens dropped. It is up to the caller to pick a safe moment for the injection (e.g.
        not during a tool call). Calling again while a previous injection is still draining appends to
        the pending queue.

        :param output:
            Text to inject, tokenized with special tokens enabled, or a (1, S) tensor of token IDs.
        """
        assert self.generator is not None, \
            "Job must be enqueued before constraining output"
        if isinstance(output, torch.Tensor):
            assert output.dim() == 2 and output.shape[0] == 1, \
                "Forced token IDs must be a (1, S) tensor"
            ids = output.to("cpu", torch.long)
        else:
            ids = self.generator.tokenizer.encode(
                output,
                encode_special_tokens = True,
                add_bos = False,
            )
        assert ids.shape[-1] > 0, "Cannot constrain output to an empty token sequence"

        self.filters_suspended = True
        for f in self.filters:
            f.is_active = False

        # Accept any text held back by a partial banned-string match. Matching is suspended while
        # forced tokens remain, so the checkpoint could never be rewound to anyway
        self._release_banned_hold()

        if self.forced_ids is not None:
            ids = torch.cat((self.forced_ids[:, self.forced_index:], ids), dim = -1)
        self.forced_ids = ids
        self.forced_index = 0
        self.forced_ids_device = None


    def set_sampler(self, sampler: Sampler | None):
        """
        Replace the job's sampler mid-generation, e.g. to sample a response block differently from the
        reasoning block before it. Takes effect from the next token the generator samples for this job.

        Call between iterations: from the thread driving Generator.iterate(), or from any coroutine on the
        event loop for an AsyncJob. Tokens sampled before the call keep their original settings, which
        includes any already sampled but not yet seen by the caller: text held back by a stop string,
        banned string or incomplete character, the rest of a speculative window accepted in the same
        iteration, and (AsyncJob) results still queued for the consumer.

        :param sampler:
            New sampler, or None for the default sampler.
        """
        self.sampler = sampler if sampler is not None else DefaultSampler()


    def set_filters(self, filters: list[Filter] | None):
        """
        Replace the job's filters mid-generation, e.g. to constrain only the response that follows a
        free-form reasoning block. The new filters start from their initial state at the next token the
        generator samples for this job (or wait for their trigger token from that point), and see none
        of the output before it. Timing and caveats are as for set_sampler().

        Any text currently held by a partial banned-string match is released (emitted with the next
        output), since a later rewind could not be replayed through filters that were not there when the
        held tokens were sampled. Banned-string matching itself continues for new text.

        Filters disabled by constrain_output_now() stay disabled while injected tokens are still pending;
        replacing them is only possible once the injection has drained.

        :param filters:
            New list of filters, or None/[] to remove all filters.
        """
        if self.forced_ids is not None:
            raise ValueError("Cannot replace filters while a constrain_output_now() injection is still pending")
        filters = list(filters) if filters else []
        self._release_banned_hold()
        self.filters = filters
        self.filters_suspended = False
        # Once the job has a generator, attach and reset here: activate() resets filters only for a job's
        # first round, so a requeued job would otherwise keep the new filters unattached
        if self.generator is not None:
            for f in self.filters:
                f.attach(self)
                f.reset()
                f.is_active = f.trigger_token is None


    def set_banned_strings(self, banned_strings: list[str] | None):
        """
        Replace the job's banned strings mid-generation. Takes effect for text sampled after the call;
        timing and caveats are as for set_sampler().

        Text currently held back by a partial match against the old banned strings is released: it can no
        longer be rewound, and it goes out with the next output unless something else holds it. Text held for
        other reasons stays held: an incomplete UTF-8 character until it completes, the start of a possible
        stop string until it resolves, and a partial match against the new banned strings that starts in the
        released text and continues into new tokens (a full match there rewinds only the new tokens).

        :param banned_strings:
            New list of banned strings (case-insensitive), or None/[] to disable banned strings.
        """
        if self.generator is not None:
            self._check_banned_strings([s.lower() for s in banned_strings or []])
        self._release_banned_hold()
        self._init_banned_strings(banned_strings)


    def _init_banned_strings(self, banned_strings: list[str] | None):
        if banned_strings:
            self.banned_strings = [s.lower() for s in banned_strings]
            self.banned_strings_utf32_buffer, self.banned_strings_utf32_offsets = \
                _strings_to_utf32(tuple(self.banned_strings))
        else:
            self.banned_strings = []
            self.banned_strings_utf32_buffer = None
            self.banned_strings_utf32_offsets = None


    def _check_banned_strings(self, banned_strings: list[str]):
        if banned_strings and self.generator.recurrent_cache is not None:
            # SWA states rewind in place, but only within their guaranteed rollback window (one page). Since the
            # matched text is tokenized by the model and its boundaries are ambiguous, require a margin below that
            # limit for the reference tokenization of each banned string. States without in-place rollback rewind
            # by restoring a past checkpoint and replaying, which has no length limit.
            guaranteed = getattr(self.generator.cache.recurrent_state_cls, "guaranteed_rollback", 0)
            if guaranteed:
                max_ref_tokens = guaranteed - 8
                for s in banned_strings:
                    ref_tokens = self.generator.tokenizer.encode(s).shape[-1]
                    assert ref_tokens <= max_ref_tokens, \
                        f"Banned string tokenizes to {ref_tokens} tokens, exceeding the maximum of " \
                        f"{max_ref_tokens} supported by this model's recurrent state rollback: {s!r}"


    def _release_banned_hold(self):
        """
        Drop the banned-string checkpoint, accepting the tokens held since it was set: they can no longer be
        rewound, the held text goes out with the next emitted output, and pages completed during the hold
        are hashed.
        """
        self.hash_deferred_pages()
        self.checkpoint = None


    def hash_completed_page(self, seq: Sequence, page_idx: int):
        """
        Give a page its content hash once all of its tokens are final, and link the following page to it.
        """
        page = seq.allocated_pages[page_idx]
        old_hash = page.phash

        if page_idx > 0:
            last_page = seq.allocated_pages[page_idx - 1]
            last_hash = last_page.phash
        else:
            last_hash = None

        page_ids = seq.sequence_ids.torch_slice(page_idx * PAGE_SIZE, (page_idx + 1) * PAGE_SIZE)
        new_hash = tensor_hash_checksum(page_ids, last_hash)

        # A deferred page may already anchor a recurrent checkpoint, stashed under the hash it had when
        # the position crossed the boundary. Move it along so it stays findable under the final hash
        rc = self.generator.recurrent_cache
        if rc is not None:
            rc.rekey(old_hash, new_hash)

        # If another referenced page has the same hash, switch to referencing that instead
        if new_hash in self.pagetable.referenced_pages:
            new_serial = page.access_serial
            page.sub_ref()
            page = self.pagetable.referenced_pages[new_hash]
            assert page.kv_position == PAGE_SIZE
            seq.allocated_pages[page_idx] = page
            seq.build_block_index_tensor()
            page.add_ref(new_serial)

        else:
            # If an unreferenced page has the same hash, clear that page
            if new_hash in self.pagetable.unreferenced_pages:
                up = self.pagetable.unreferenced_pages[new_hash]
                up.clear()

            # Update the hash
            page.update_hash(new_hash)

        # Allow completing the final page without starting a new one (for requeue)
        if page_idx + 1 < len(seq.allocated_pages):
            page = seq.allocated_pages[page_idx + 1]
            page.prev_hash = new_hash
            page.can_revert = False


    def hash_deferred_pages(self):
        """
        Hash the pages that completed while a banned-string checkpoint was holding tokens. Called when the
        held tokens become final: the hold is released, or the job ends or requeues with the checkpoint in
        place. A rewind discards the deferred pages instead, since it truncates them.
        """
        if self.checkpoint is None:
            return
        for seq, page_idx in self.checkpoint["deferred_pages"]:
            self.hash_completed_page(seq, page_idx)
        self.checkpoint["deferred_pages"].clear()


    def _pop_forced_token(self, device) -> torch.Tensor:
        """
        Next pending forced token as a (1, 1) tensor on the sampling device.
        """
        if self.forced_ids_device is None:
            self.forced_ids_device = self.forced_ids.to(device)
        next_token = self.forced_ids_device[:, self.forced_index : self.forced_index + 1]
        self.forced_index += 1
        self.forced_sample = True
        if self.forced_index >= self.forced_ids.shape[-1]:
            self.forced_ids = None
            self.forced_ids_device = None
            self.forced_index = 0
        return next_token


    def receive_logits(
        self,
        logits: torch.Tensor,
    ):
        # TODO: (cfg)
        # assert logits.shape[0] == len(self.sequences) == (2 if self.gen_settings.cfg_scale is not None else 1)
        # assert logits.shape[0] == len(self.sequences)
        # assert self.is_prefill_done()
        # assert all(seq.live for seq in self.sequences)

        # Fail fast on NaN/Inf logits: sampling them yields a fixed garbage token (argmax over
        # NaN is id 0) that can loop, which hides the fault. Checked on the job's first sampled
        # token only, which costs one sync per job
        if self.new_tokens < 1:
            if not bool(torch.isfinite(logits).all()):
                n_bad = int((~torch.isfinite(logits)).sum())
                raise NonFiniteLogits(
                    f"Job {self.identifier!r} (serial {self.serial_number}) produced {n_bad} non-finite "
                    f"logits at step {self.new_tokens} (tensor {tuple(logits.shape)} on {logits.device}). "
                    f"This is a kernel bug, not bad sampling settings. A/B the fused decode paths to "
                    f"bisect: EXL3_BC_MLA=0, EXL3_BC_GDN=0, EXL3_BC_ATTN=0, EXL3_BC_DSA=0, EXL3_GRAPHS=0."
                )

        # A pending forced token (constrain_output_now) replaces the sampler's choice; everything
        # downstream treats it as a regular sample. Token healing (new_tokens == -1) resolves first
        if self.forced_ids is not None and self.new_tokens >= 0:
            next_token = self._pop_forced_token(logits.device)
        else:
            next_token = self.sampler.forward(
                logits,
                self.current_device_ids,
                self.rng.randint(0, (1<<32)-1),
                self.generator.tokenizer,
                logit_mask = self.device_logit_mask
            )

        next_prob, next_k_tokens, next_k_probs = None, None, None

        if self.return_probs or self.return_top_tokens > 0:
            probs = torch.softmax(logits.float(), dim = -1)

            if self.return_probs:
                next_prob = torch.gather(probs.squeeze(0), dim = 1, index = next_token)

            if self.return_top_tokens > 0:
                sorted_probs, sorted_indices = torch.sort(probs, dim = -1, descending = True)
                next_k_tokens = sorted_indices[:, :, :self.return_top_tokens]
                next_k_probs = sorted_probs[:, :, :self.return_top_tokens]

        return next_token, next_k_tokens, next_k_probs, next_prob


    def receive_sample(
        self,
        logits: torch.Tensor | None,
        next_token: torch.Tensor | None,
        next_k_tokens: torch.Tensor | None,
        next_k_probs: torch.Tensor | None,
        next_prob: torch.Tensor | None,
        results: list,
        first_sample_in_sd_batch: bool = True
    ):
        """
        Accept one sampled token and turn it into stream events, state updates and termination decisions.

        The sampled token is appended to every sequence, completed cache pages are hashed for later prefix reuse,
        active filters are advanced, and the decoded text/tokens/probabilities are buffered until it is safe to
        emit them. Output is held when token healing needs to remove the unhealed prefix, when a partial Unicode
        character or stop string may still complete, or when banned-string handling may need to rewind to a
        checkpoint and suppress text. The returned requeue flag asks the generator to stop this physical job and
        enqueue a new one with the current sequence as its prompt, which bounds per-job cache growth and lets long
        generations pass through prompt-cache allocation again.
        """
        next_token = next_token.cpu()
        next_token_i = next_token.item()
        forced_sample = self.forced_sample
        self.forced_sample = False

        # Activate/advance filters if not healing
        filter_eos_condition = False
        if self.new_tokens >= 0 and not self.filters_suspended:
            for f in self.filters:
                filter_eos_condition |= f.feed(next_token_i)

        # Accept token
        self.new_tokens += 1
        requeue_now = self.new_tokens > self.max_rq_tokens - self.rq_margin

        for seq in self.sequences:

            # Accept new token
            seq.sequence_ids.append(next_token)
            page_before = seq.kv_position // PAGE_SIZE
            seq.kv_position += 1
            page_after = seq.kv_position // PAGE_SIZE

            # Hash completed page
            if page_after > page_before:

                # A page that completes while a banned-string checkpoint holds tokens contains tokens that
                # may still be rewound, so it can't be published under its content hash yet. Defer it until
                # the hold resolves. The next page starts filling right away: link it to the completed
                # page's current (unique) hash in the meantime, so it never reads as the root of a sequence
                if self.checkpoint and self.checkpoint["offset"] > 0:
                    self.checkpoint["deferred_pages"].append((seq, page_before))
                    if page_after < len(seq.allocated_pages):
                        seq.allocated_pages[page_after].prev_hash = seq.allocated_pages[page_before].phash
                else:
                    self.hash_completed_page(seq, page_before)

        # Stream output

        def emit(
            results_: list,
            emit_eos: bool = False,
            eos_reason: str = None,
            emit_held = False,
            suppressed_text = None,
            suppressed_tokens = None,
            stop_token: int = None,
            stop_string: str = None,
            rem_held_text: str = None
        ):
            nonlocal requeue_now

            # A finished job never requeues (Generator would prefer requeue over EOS if both signals coincide)
            if emit_eos:
                requeue_now = False

            r = {
                "job": self,
                "stage": "streaming",
                "eos": emit_eos,
                "serial": self.serial_number,
            }

            if eos_reason is not None:
                r.update({ "eos_reason": eos_reason })
                if eos_reason == "stop_token":
                    id_to_piece = self.generator.tokenizer.get_id_to_piece_list(True)
                    r.update({
                        "eos_triggering_token_id": stop_token,
                        "eos_triggering_token_str": id_to_piece[stop_token]
                    })
                    pass
                if eos_reason == "stop_string":
                    r.update({ "eos_triggering_string": stop_string })

            # Requeue if we reach max_rq_tokens
            if requeue_now:
                r.update({ "requeue": True })
                requeue_now = True

                # Can't revert to checkpoint after requeuing, so just emit whatever was being held
                if self.checkpoint is not None:
                    emit_held = True

            if emit_held:
                if emit_eos and "�" in self.held_text and self.held_tokens:
                    # The job ends with pieces still held (max_new_tokens, a filter, a stop string): characters
                    # split across those pieces are repaired by decoding them together; a character the last
                    # token left incomplete stays as it is, nothing more is coming
                    self.held_text = self.generator.tokenizer.decode(
                        self.held_tokens.torch(),
                        decode_special_tokens = self.decode_special_tokens
                    )[0]
                if self.held_text != "":
                    self.full_completion += self.held_text
                    r.update({ "text": self.held_text })
                    self.held_text = ""
                if self.held_tokens:
                    r.update({ "token_ids": self.held_tokens.torch().clone() })
                    self.held_tokens.clear()
                if self.held_probs:
                    r.update({ "token_probs": self.held_probs.torch().clone() })
                    self.held_probs.clear()
                if self.held_k_tokens:
                    r.update({ "top_k_tokens": self.held_k_tokens.torch().clone() })
                    r.update({ "top_k_probs": self.held_k_probs.torch().clone() })
                    self.held_k_tokens.clear()
                    self.held_k_probs.clear()
                if self.held_logits:
                    r.update({ "logits": self.held_logits.torch().clone() })
                    self.held_logits.clear()

            if suppressed_text:
                r.update({ "suppressed_text": suppressed_text })
                r.update({ "suppressed_tokens": suppressed_tokens.torch() })

            if emit_eos or requeue_now:
                # Nothing can be rewound past this point, so pages deferred by a held checkpoint are final
                self.hash_deferred_pages()
                self.time_last_token = time.time()
                self.time_enqueued += self.time_first_prefill - self.time_enqueue
                self.time_prefill += self.time_first_token - self.time_first_prefill
                self.time_generate += self.time_last_token - self.time_first_token

            if emit_eos:
                self.is_finished = True
                cached = self.rq_cached if self.rq_cached is not None else (
                    self.cached_pages // len(self.sequences),
                    (self.cached_pages * PAGE_SIZE + self.cached_tokens) // len(self.sequences),
                )
                r.update({
                    "full_completion": self.full_completion,
                    "new_tokens": self.rq_new_tokens + self.new_tokens,
                    "prompt_tokens": self.rq_prompt_tokens or len(self.sequences[0].input_ids),
                    "time_enqueued": self.time_enqueued,
                    "time_prefill": self.time_prefill,
                    "time_generate": self.time_generate,
                    "cached_pages": cached[0],
                    "cached_tokens": cached[1],
                })
                if self.generator.draft_model or self.generator.ngram_match_min or self.generator.hybrid_draft_tokens:
                    r.update({
                        "accepted_draft_tokens": self.accepted_draft_tokens,
                        "rejected_draft_tokens": self.rejected_draft_tokens
                    })
                if eos_reason == "stop_string":
                    self.held_text = rem_held_text
                rh = {}
                if self.held_text:
                    rh.update({ "text": self.held_text })
                if self.held_tokens:
                    rh.update({ "token_ids": self.held_tokens.torch().clone() })
                if self.held_probs:
                    rh.update({ "token_probs": self.held_probs.torch().clone() })
                if self.held_k_tokens:
                    rh.update({ "top_k_tokens": self.held_k_tokens.torch().clone() })
                    rh.update({ "top_k_probs": self.held_k_probs.torch().clone() })
                if self.held_logits:
                    rh.update({ "logits": self.held_logits.torch().clone() })
                if rh:
                    r.update({ "held": rh })

            if self.identifier is not None:
                r.update({ "identifier": self.identifier })

            results_.append(r)
            return emit_eos, next_token, requeue_now

        # Decode and buffer output
        id_to_piece = self.generator.tokenizer.get_id_to_piece_list(self.decode_special_tokens)
        new_text = id_to_piece[next_token.item()]

        if self.new_tokens == 0:
            unhealed = id_to_piece[self.prefix_token[0].item()]
            new_text = new_text[len(unhealed):]

        held_text_before = self.held_text
        self.held_text += new_text
        self.held_tokens.append(next_token)
        if self.return_probs:
            self.held_probs.append(next_prob)
        if self.return_top_tokens > 0:
            self.held_k_tokens.append(next_k_tokens)
            self.held_k_probs.append(next_k_probs)
        if self.return_logits:
            self.held_logits.append(logits[:1, :, :])

        token = next_token.item()

        # End on stop tokens
        if token in self.stop_tokens:
            return emit(results, emit_eos = True, eos_reason = "stop_token", stop_token = token)

        # Stop if we reach max_new_tokens. Exact: a limit reached inside a speculative window is fine, the
        # generator rejects the window's remaining draft positions when a job ends mid-window (eos path)
        if self.new_tokens >= self.max_new_tokens:
            return emit(results, emit_eos = True, emit_held = True, eos_reason = "max_new_tokens")

        # End on filter completed
        if filter_eos_condition:
            return emit(results, emit_eos = True, emit_held = True, eos_reason = "end_filter")

        # Hold text while it contains an incomplete character
        if "�" in self.held_text:
            test_decode = self.generator.tokenizer.decode(
                self.held_tokens.torch(),
                decode_special_tokens = self.decode_special_tokens
            )[0]
            if test_decode.endswith("�") and len(test_decode) <= self.stop_string_max_length + 20:
                # The trailing character may still be completed by upcoming tokens; keep holding, but not
                # forever, in case a broken generation never completes the character
                return emit(results)
            # Tail is complete: adopt the full decode as the held text. Any remaining replacement characters
            # are interior, representing invalid bytes that no later token can repair
            self.held_text = test_decode

        # Hold text as long as it contains part of a banned string
        def unset_checkpoint():
            self.hash_deferred_pages()
            self.checkpoint = None

        def set_checkpoint():
            if self.checkpoint is None:
                self.checkpoint = {
                    "offset": 1,
                    "held_text": held_text_before,   # not held_text[:-len(new_text)]: new_text may be empty
                    "held_tokens": self.held_tokens.clone(1),
                    "held_probs": self.held_probs.clone(1),
                    "held_k_tokens": self.held_k_tokens.clone(1),
                    "held_k_probs": self.held_k_probs.clone(1),
                    "held_logits": self.held_logits.clone(1),
                    "explored_tokens": [next_token.item()],
                    "deferred_pages": [],
                }
                # Keep the nearest recurrent stash warm in the LRU cache in case this hold ends in a rewind
                if self.recurrent_state is not None:
                    self.find_recurrent_stash(self.sequences[0].kv_position - 1)
            else:
                self.checkpoint["offset"] += 1
                if self.checkpoint["offset"] == 1:
                    self.checkpoint["explored_tokens"].append(next_token.item())

        def rewind_checkpoint():
            assert self.checkpoint is not None
            offset = self.checkpoint["offset"]
            self.new_tokens -= offset

            # Roll back filter state over the rewound tokens (every token counted in the offset was
            # fed to the filters when it was sampled)
            for f in self.filters:
                f.rewind(offset)
            # The suffix automaton re-accepts from the truncated sequence on its next query
            self.sam_match = None

            # The attention cache rewinds by truncation, but recurrent states advance destructively. SWA states
            # can roll back in place within their stored window; other states are restored from the most recent
            # page-aligned checkpoint at or before the rewind position (or reset, if none survives in the cache)
            # and prefill then replays the gap, since it re-processes complete pages whenever the state position
            # is behind the K/V position.
            replay_from = None
            if self.recurrent_state is not None:
                target = self.sequences[0].kv_position - offset
                # During draft verification the state runs ahead of the accepted K/V position, so rewind to the
                # target position rather than by the checkpoint offset; every side of the pair must be able to
                # roll back in place, else the pair is restored from a stash
                if self.recurrent_state.can_rewind_to(target):
                    self.recurrent_state.rewind_to(target)
                else:
                    stashed = self.find_recurrent_stash(target)
                    self.free_recurrent_state()
                    if stashed is not None:
                        replay_from = stashed["position"]
                        self.recurrent_state = self.generator.recurrent_state_from_stashed(stashed, replay_from)
                    else:
                        replay_from = 0
                        self.recurrent_state = self.generator.new_recurrent_state()
                    self.last_recurrent_checkpoint_pos = replay_from or None

            for seq in self.sequences:
                p_page = seq.kv_position // PAGE_SIZE
                seq.kv_position -= offset
                seq.sequence_ids.truncate(len(seq.sequence_ids) - offset)
                self.pinned_ids_valid = min(self.pinned_ids_valid, len(seq.sequence_ids))
                n_page = seq.kv_position // PAGE_SIZE
                for pi in range(n_page, len(seq.allocated_pages)):
                    page = seq.allocated_pages[pi]
                    # Pages beyond the last accepted position can hold pre-written draft tokens from an abandoned
                    # verification window; roll those back too, stopping at the write frontier
                    if pi > p_page and page.kv_position == 0:
                        break
                    page.can_revert = False
                    if page.kv_position == PAGE_SIZE:
                        page.update_hash(random_hash())
                    if pi == n_page:
                        page.kv_position = seq.kv_position - pi * PAGE_SIZE
                    else:
                        page.kv_position = 0
                # Pages between the replay position and the rewind target keep their metadata: their contents are
                # re-processed by prefill (which ignores page completeness while the state position trails the K/V
                # position) and rewritten with identical values, and they may include shared prompt-cache pages
                if replay_from is not None:
                    seq.kv_position = replay_from
                    seq.prefill_complete = False

            # An MTP draft carry refers to the pre-rewind context; drop it so drafting pauses until the next
            # target forward (or replay prefill) provides a fresh one. Signal the generator that any in-flight
            # draft verification window must be abandoned.
            self.mtp_last_hidden = None
            self.checkpoint_rewound = True
            # Every deferred page held rewound tokens and was truncated above
            self.checkpoint["deferred_pages"].clear()
            off_tokens = self.held_tokens.slice(len(self.checkpoint["held_tokens"]), None)
            off_text = self.held_text[len(self.checkpoint["held_text"]):]
            self.held_text = self.checkpoint["held_text"]
            self.held_tokens = self.checkpoint["held_tokens"].clone()
            self.held_probs = self.checkpoint["held_probs"].clone()
            self.held_k_tokens = self.checkpoint["held_k_tokens"].clone()
            self.held_k_probs = self.checkpoint["held_k_probs"].clone()
            self.held_logits = self.checkpoint["held_logits"].clone()
            # The checkpoint stays in place (offset 0, explored tokens) in case the resampled token is
            # rejected too. The caller emits the restored buffers right away, so what a second rewind
            # must restore is the empty state after that emit, not the pre-match contents again
            self.checkpoint["offset"] = 0
            self.checkpoint["held_text"] = ""
            for k in ("held_tokens", "held_probs", "held_k_tokens", "held_k_probs", "held_logits"):
                self.checkpoint[k].clear()
            return off_tokens, off_text

        if requeue_now:
            unset_checkpoint()

        # Banned-string matching is suspended for forced tokens (and while more remain queued), so a
        # rewind can never truncate an injection
        elif (
            self.banned_strings_utf32_offsets is not None
            and self.new_tokens > 0
            and not forced_sample
            and self.forced_ids is None
        ):
            match = ext.partial_strings_match(
                np.frombuffer(self.held_text.lower().encode("utf-32-le"), dtype = np.uint8),
                self.banned_strings_utf32_offsets,
                self.banned_strings_utf32_buffer
            )
            if match >= 0:
                set_checkpoint()
                offending_tokens, offending_text = rewind_checkpoint()
                return emit(
                    results,
                    emit_held = True,
                    suppressed_text = offending_text,
                    suppressed_tokens = offending_tokens
                )
            elif match == -2:
                set_checkpoint()
                return emit(results)
            else:
                unset_checkpoint()

        # End on stop strings
        if self.stop_strings_utf32_offsets is not None:
            match = ext.partial_strings_match(
                np.frombuffer(self.held_text.encode("utf-32-le"), dtype = np.uint8),
                self.stop_strings_utf32_offsets,
                self.stop_strings_utf32_buffer
            )
            if match >= 0:
                held = self.held_text[match:]
                self.held_text = self.held_text[:match]
                for s in self.stop_strings:
                    if held.startswith(s):
                        return emit(
                            results,
                            emit_eos = True,
                            emit_held = True,
                            eos_reason = "stop_string",
                            stop_string = s,
                            rem_held_text = held
                        )
                assert False, "Detected stop string but couldn't identify it (logic error)"
            if match == -2:
                return emit(results)

        # Stop if loop is detected
        if self.loop_detector:
            if self.loop_detector.feed_many(self.held_tokens.torch()):
                return emit(results, emit_eos = True, emit_held = True, eos_reason = "loop_detected")

        # Stream output
        return emit(results, emit_held = True)


    def prepare_for_requeue(self):
        """
        Reinitialize this single-sequence job so generation can continue as a freshly queued request.

        Requeueing turns the full sequence generated so far into the new prompt, reduces the remaining token
        limits, carries over streaming buffers/timing/filter state, and disables token healing because it already
        happened on the first pass. The resulting job keeps the original serial number so callers see one logical
        stream even though the generator schedules it as another pending job.
        """
        assert len(self.sequences) == 1

        seq = self.sequences[0]
        last_completed_tokens = len(seq.sequence_ids) - len(seq.input_ids)
        new_input = seq.sequence_ids.torch()

        rq_state = {
            "rng": self.rng,
            "stop_strings": self.stop_strings,
            "stop_tokens": self.stop_tokens,
            "stop_strings_utf32_buffer": self.stop_strings_utf32_buffer,
            "stop_strings_utf32_offsets": self.stop_strings_utf32_offsets,
            "held_text": self.held_text,
            "held_tokens": self.held_tokens,
            "held_probs": self.held_probs,
            "held_k_tokens": self.held_k_tokens,
            "held_k_probs": self.held_k_probs,
            "held_logits": self.held_logits,
            "full_completion": self.full_completion,
            "time_enqueued": self.time_enqueued,
            "time_prefill": self.time_prefill,
            "time_generate": self.time_generate,
            # Every token accepted so far counts, new_tokens restarts from zero in each segment
            "rq_new_tokens": self.rq_new_tokens + self.new_tokens,
            "accepted_draft_tokens": self.accepted_draft_tokens,
            "rejected_draft_tokens": self.rejected_draft_tokens,
            "prompt_tokens": self.rq_prompt_tokens or len(seq.input_ids),
            "cached": self.rq_cached if self.rq_cached is not None else (
                self.cached_pages, self.cached_pages * PAGE_SIZE + self.cached_tokens),
            "sam": self.sam,
            "loop_detector": self.loop_detector,
            "forced_ids": None if self.forced_ids is None else self.forced_ids[:, self.forced_index:],
            "filters_suspended": self.filters_suspended,
        }

        serial_number = self.serial_number
        generator = self.generator

        rq_job = self
        self.__init__(
            input_ids = new_input,
            max_new_tokens = self.max_new_tokens - last_completed_tokens,
            min_new_tokens = max(self.min_new_tokens - last_completed_tokens, 0),
            sampler = self.sampler,
            decode_special_tokens = self.decode_special_tokens,
            return_top_tokens = self.return_top_tokens,
            return_logits = self.return_logits,
            return_probs = self.return_probs,
            filters = self.filters,  # Carries over state
            token_healing = False,  # Token healed on first round
            identifier = self.identifier,
            banned_strings = self.banned_strings,
            embeddings = self.embeddings,
            max_rq_tokens = self.orig_max_rq_tokens,
            stop_on_loop = self.stop_on_loop,
            rq_state = rq_state,
        )

        rq_job.prepare_for_queue(generator, serial_number, rq = True)
        return rq_job


    def prepare_for_queue(self, generator, serial_number: int, rq: bool = False):
        """
        Attach the job to a generator and prepare its static queue-time state.

        This runs before the job is placed in pending_jobs and before physical cache pages are allocated. It hashes
        full prompt pages so the page table can later find reusable K/V cache entries, counts the additional unique
        pages required for generation, checks the request against cache and batch limits, initializes streaming
        buffers for non-requeued jobs, and prepares any model-specific embedding/position metadata needed by prefill.
        """

        # Attach to generator
        self.serial_number = serial_number
        self.generator = generator
        self.pagetable = generator.pagetable
        self.skips = 0

        # The cache bounds the response: past the prompt, every generated token and the drafter's
        # speculative window (written past the budget by a verification pass) have to fit. That is
        # the limit when none is given, and the cap on one that is, so a chunked job that writes
        # its way to the end of the cache ends with max_new_tokens instead of asserting at the
        # requeue that finds no pages left (the cap holds for the requeued rounds too, whose prompt
        # is the sequence so far). A prompt with no room at all keeps its limit and fails the page
        # check below, which is the message the caller expects for that
        room = self.generator.max_total_tokens - max(len(s.input_ids) for s in self.sequences) \
               - 1 - self.generator.max_draft_tokens
        if self.max_new_tokens is None:
            self.max_new_tokens = max(1, room)
        elif room >= 1:
            self.max_new_tokens = min(self.max_new_tokens, room)

        # Align max_rq_tokens to page boundary or recurrent checkpoint
        if self.max_rq_tokens is not None:
            if len(self.sequences) == 1:
                boundary = self.generator.recurrent_checkpoint_interval \
                    if self.generator.recurrent_cache is not None else PAGE_SIZE
                x = len(self.sequences[0].input_ids)
                y = (x - 1 + self.max_rq_tokens + boundary - 1) // boundary * boundary
                # The final segment: a budget aligned to the end of the cache leaves no room for the
                # speculative window past it, and no requeue can follow it anyway, so it is cut to what
                # the cache holds rather than refused (issue: a 61k-token prompt in a 64k cache with a
                # 31-token draft window could not be enqueued at all)
                y = min(y, self.generator.max_total_tokens - self.generator.max_draft_tokens)
                self.max_rq_tokens = max(1, y - x)
            # The requeue lands exactly on the aligned boundary, so a recurrent checkpoint stashed there
            # resumes the next segment with nothing to replay. A speculative window writes K/V past that
            # point, so drafting jobs reserve the window beyond the budget rather than requeueing early
            # (early by the window misses the boundary and replays up to a checkpoint interval; early by
            # a page shortens every segment by a page and requeues up to twice as often)
            self.rq_margin = 0
            self.rq_headroom = self.generator.max_draft_tokens
        else:
            # Default budget: the whole response plus one speculative window past the limit
            self.max_rq_tokens = self.max_new_tokens + 1 + self.generator.max_draft_tokens
            self.rq_margin = self.generator.max_draft_tokens
            self.rq_headroom = 0

        # Compatibility checks
        self._check_banned_strings(self.banned_strings)

        # Hash full pages of input IDs
        all_unique_hashes = set()
        all_unique_pages = 0
        for seq in self.sequences:
            unique_hashes, unique_pages = seq.prepare(self.prefix_token is not None, self.max_rq_tokens + self.rq_headroom)
            if self.generator.mtp_draft:
                seq.max_cached_pages = max(0, (len(seq.sequence_ids) - 2) // PAGE_SIZE)
                cached_hashes = seq.page_hashes[:seq.max_cached_pages]
                omitted_pages = len(seq.page_hashes) - len(cached_hashes)
                all_unique_hashes.update(cached_hashes)
                all_unique_pages += unique_pages + omitted_pages
            else:
                all_unique_hashes |= unique_hashes
                all_unique_pages += unique_pages
        self.all_unique_hashes = list(all_unique_hashes)

        # Make sure the request can potentially fit
        total_pages = len(self.all_unique_hashes) + all_unique_pages
        max_pages = self.pagetable.max_pages
        assert total_pages <= max_pages, \
            f"Job requires {total_pages} pages (only {max_pages} available) and cannot " + \
            f"be enqueued. Total cache allocated is {max_pages} * {PAGE_SIZE} = " + \
            f"{self.generator.max_total_tokens} tokens"
        assert len(self.sequences) <= self.generator.max_batch_size, \
            f"Job requires a minimum batch size of {len(self.sequences)}. Max supported batch size in" + \
            f"generator is {self.generator.max_batch_size}."

        # Initial conditions
        if not rq:
            self.held_text = ""
            self.held_tokens = SeqTensor((1, 0), dtype = torch.long, seq_dim = -1)
            self.held_k_tokens = SeqTensor((1, 0, self.return_top_tokens), dtype = torch.long, seq_dim = 1)
            self.held_k_probs = SeqTensor((1, 0, self.return_top_tokens), dtype = torch.float, seq_dim = 1)
            self.held_probs = SeqTensor((1, 0), dtype = torch.float, seq_dim = -1)
            self.held_logits = SeqTensor((1, 0, self.generator.padded_vocab_size), dtype = torch.float, seq_dim = 1)
            self.full_completion = ""
            self.sam = ext.BC_SAM() if (generator.ngram_match_min or generator.hybrid_draft_tokens) else None
            self.sam_match = None   # (sequence length, match begin, match end) of the last suffix-automaton query
            self.corpus_cursor = generator.ngram_corpus.cursor() if generator.ngram_corpus else None

        self.time_enqueue = time.time()

        # Prepare MRoPE embeddings
        if self.embeddings and generator.model.caps.get("mrope"):
            ids = self.sequences[0].sequence_ids.torch()
            freqs, offset = generator.model.g_rope.get_mrope_freqs(
                ids,
                self.embeddings,
                ids.shape[-1]  # + self.max_new_tokens
            )
            self.alt_rope_freqs = freqs
            self.alt_rope_offset = offset - ids.shape[-1]
        else:
            self.alt_rope_freqs = None
            self.alt_rope_offset = 0


    def current_new_pages_required(self):
        new_pages = 0
        for h in self.all_unique_hashes:
            if h not in self.pagetable.referenced_pages:
                new_pages += 1
        for s in self.sequences:
            omitted_pages = 0 if s.max_cached_pages is None else len(s.page_hashes) - s.max_cached_pages
            new_pages += s.new_unique_pages + omitted_pages
        return new_pages


    def prefill(self, results: list, chunk_size: int | None = None):
        """
        Run prompt prefill chunks for already allocated cache pages.

        iterate_start_jobs() allocates or revives pages before this method is called. prefill() then advances each
        sequence's kv_position through the prompt, skipping any prefix whose K/V pages were already cached, running
        model forward passes for uncached chunks, updating page hashes as pages become complete, and stashing
        recurrent checkpoints when applicable. It emits progress events but does not sample new completion tokens.

        chunk_size, when given, bounds the forward pass of this call below the generator's max_chunk_size (prompt
        ingestion alongside generating jobs). The cached-page skip still covers the full max_chunk_size window.
        """

        if self.time_first_prefill is None:
            self.time_first_prefill = time.time()

        progress = 0

        for seq in self.sequences:
            if seq.prefill_complete:
                continue

            cp_pos = self.recurrent_state.position if self.recurrent_state is not None else -1

            prefill_start = seq.kv_position
            prefill_end = seq.kv_position + self.generator.max_chunk_size
            prefill_end = (prefill_end // PAGE_SIZE) * PAGE_SIZE
            prefill_end = min(prefill_end, len(seq.sequence_ids) - 1)

            atomic_mm_prefill = bool(self.embeddings) and self.generator.model.caps.get("atomic_mm_prefill")
            mm_exact_chunks = bool(self.embeddings) and self.generator.model.caps.get("mm_exact_chunks")
            # assert not atomic_mm_prefill or not self.recurrent_state, \
            #     "Atomic prefill is not supported for recurrent models"

            p0 = prefill_start // PAGE_SIZE
            p1 = (prefill_end + PAGE_SIZE - 1) // PAGE_SIZE
            for local_idx in range(p0, p1):
                if 0 <= cp_pos <= seq.kv_position:
                    break
                page = seq.allocated_pages[local_idx]
                if page.kv_position == PAGE_SIZE:
                    prefill_start = (local_idx + 1) * PAGE_SIZE
                    seq.kv_position = prefill_start
                    self.cached_pages += 1
                    page.can_revert = False
                else:
                    break

            p0 = prefill_start // PAGE_SIZE
            for local_idx in range(p0, p1):
                if 0 <= cp_pos <= seq.kv_position:
                    break
                page = seq.allocated_pages[local_idx]
                if page.kv_position == PAGE_SIZE:
                    prefill_end = local_idx * PAGE_SIZE
                    break

            # A reduced chunk bounds the forward pass only, after the cached pages were skipped over the full
            # window above, so a job resuming a cached prompt still walks it at the usual rate
            if chunk_size is not None:
                prefill_end = min(prefill_end, (prefill_start + chunk_size) // PAGE_SIZE * PAGE_SIZE)

            if prefill_end <= prefill_start:
                continue

            assert prefill_start % PAGE_SIZE == 0 or mm_exact_chunks
            prefill_ids = seq.sequence_ids.torch_slice(prefill_start, prefill_end)

            # Special case for partial last page, check if there's a page anywhere in the cache that
            # partially matches, then copy keys/values from there. Skip this step for recurrent models
            # since the recurrent checkpoint will always be on a page boundary
            p0 = prefill_start // PAGE_SIZE
            p1 = prefill_end // PAGE_SIZE
            if prefill_start == p0 * PAGE_SIZE and self.generator.recurrent_cache is None:
                prev_hash = None if p0 == 0 else seq.allocated_pages[p0 - 1].phash
                best_match = 0
                best_match_page = None
                for page in self.pagetable.all_pages:
                    if page.prev_hash != prev_hash or id(page) == id(seq.allocated_pages[p0]):
                        continue
                    match = ext.count_match_tensor(page.sequence, prefill_ids, page.kv_position)
                    if match > best_match:
                        best_match = match
                        best_match_page = page

                # MTP needs one real target-model token at the end of prompt prefill to recover
                # the post-final-norm carry state. Partial-page reuse must not consume that token.
                if self.generator.mtp_draft and prefill_end == len(seq.sequence_ids) - 1:
                    best_match = min(best_match, prefill_ids.shape[-1] - 1)

                if best_match_page and best_match > 1:
                    page = seq.allocated_pages[p0]
                    for c in [self.generator.cache] if not self.generator.draft_model else \
                            [self.generator.cache, self.generator.draft_cache]:
                        c.copy_page(
                            c,
                            best_match_page.page_index,
                            page.page_index,
                            best_match,
                        )
                    page.prev_hash = best_match_page.prev_hash
                    page.sequence[:, :best_match].copy_(prefill_ids[:, :best_match])
                    prefill_ids = prefill_ids[:, best_match:]
                    prefill_start += best_match
                    seq.kv_position += best_match
                    page.kv_position = best_match
                    page.can_revert = False
                    self.cached_tokens += best_match
                    progress += best_match

            # For recurrent models, do a separate forward pass for the last page to get the latest possible checkpoint
            recurrent_last_page = False
            if self.generator.recurrent_cache is not None:
                seqlen = len(seq.sequence_ids) - 1
                last_page_b = seqlen // PAGE_SIZE * PAGE_SIZE
                if prefill_start < last_page_b <= prefill_end:
                    prefill_end = last_page_b
                    recurrent_last_page = True
                    prefill_ids = seq.sequence_ids.torch_slice(prefill_start, prefill_end)

            # Exact multimodal chunking (DeepSeek-V4 vision): an image span is prefilled as
            # exactly one chunk (non-causal within itself) and never re-fed, since the
            # ring / compressor / pool states are streams. Text chunks end at a span start and
            # a span chunk ends at the span end, page boundaries notwithstanding (pages are
            # allocated for the whole prompt)
            if mm_exact_chunks and prefill_end > prefill_start:
                for s_beg, s_end in self.mm_exact_spans(seq):
                    if s_beg < prefill_start < s_end:
                        raise RuntimeError(
                            "DeepSeek-V4 vision: prefill would start inside an image span "
                            "(the image is only partially cached); clear the cache or resend the prompt")
                    if prefill_start == s_beg:
                        cut = s_end
                    elif prefill_start < s_beg < prefill_end:
                        cut = s_beg
                    else:
                        continue
                    if cut != prefill_end:
                        prefill_end = cut
                        p1 = (prefill_end + PAGE_SIZE - 1) // PAGE_SIZE
                        recurrent_last_page = False
                        prefill_ids = seq.sequence_ids.torch_slice(prefill_start, prefill_end)
                    break

            # Inference
            if prefill_end > prefill_start:

                # For atomic MM prefills, if the current chunk ends on a MM token, expand to cover the entire MM
                # span. Cache pages are already allocated for the full span, so this will process part of the next
                # chunk redundantly but won't write out-of-bounds since cache pages are already allocated for the
                # whole input sequence including MM tokens. (This is for Gemma4 specifically, which has image token
                # spans of at most 280 tokens.)
                # The mask covers only the prompt: a rewind replay chunk past it (generated tokens
                # are never multimodal) must not index beyond the mask
                if atomic_mm_prefill:
                    ext_prefill_end = prefill_end
                    while (
                        ext_prefill_end < len(seq.sequence_ids) - 1 and
                        ext_prefill_end < len(seq.multimodal_mask) and
                        seq.multimodal_mask[ext_prefill_end - 1] and
                        seq.multimodal_mask[ext_prefill_end]
                    ):
                        ext_prefill_end += 1
                    prefill_ids = seq.sequence_ids.torch_slice(prefill_start, ext_prefill_end)

                # If the chunk starts inside a multimodal span (an atomic MM prefill re-feeds the
                # extension processed by the previous chunk), tell the span builder how far the
                # span extends before the chunk, so non-causal attention windows cover the whole
                # span rather than just the in-chunk suffix
                mm_span_prefix = 0
                # The mask covers only the prompt; generated tokens are never multimodal
                if self.embeddings and prefill_start <= len(seq.multimodal_mask):
                    pp = prefill_start
                    while pp > 0 and seq.multimodal_mask[pp - 1]:
                        mm_span_prefix += 1
                        pp -= 1

                # Rewind prefill can exceed the prompt-length table, which the RoPE kernel reads unchecked
                if self.alt_rope_freqs is not None and prefill_end > self.alt_rope_freqs.shape[-2]:
                    ids = seq.sequence_ids.torch()
                    # Appending text advances the next position and sequence length equally,
                    # leaving alt_rope_offset unchanged for decode
                    self.alt_rope_freqs, _ = self.generator.model.g_rope.get_mrope_freqs(
                        ids, self.embeddings, ids.shape[-1]
                    )

                params = {
                    "attn_mode": "flash_attn",
                    "block_table": seq.block_index_tensor,
                    "cache": self.generator.cache,
                    "cache_seqlens": torch.tensor([prefill_start], dtype = torch.int32),
                    "recurrent_states": [self.recurrent_state.target] if self.recurrent_state is not None and
                                        self.recurrent_state.target is not None else None,
                    "indexed_embeddings": self.embeddings,
                    "inv_freq": self.alt_rope_freqs,
                    "mm_span_prefix": mm_span_prefix,
                }
                if self.generator.draft_model:
                    params.update(self.generator.draft_model.draft_verifier_params)
                dm = self.generator.draft_model
                if self.generator.mtp_draft and not (dm is not None and dm.caps.get("draft_uses_target_cache")):
                    # MTP needs the target's post-final-norm state for every prompt token.
                    # Normal prefill stops at the last cache-writing layer, before final norm.
                    params["last_tokens_only"] = 1
                    self.generator.model.forward(input_ids = prefill_ids, params = params)
                else:
                    # (A drafter fed the last decoder layer's output takes the regular prefill, which runs
                    # through that layer)
                    self.generator.model.prefill(input_ids = prefill_ids, params = params)

                if self.generator.dflash_draft:
                    self.generator.draft_model.update_kv_from_target(
                        target_hidden = params.get("export_states"),
                        cache = self.generator.draft_cache,
                        params = {
                            "block_table": seq.block_index_tensor,
                            "cache_seqlens": params["cache_seqlens"],
                            "recurrent_states": [self.recurrent_state.draft] if self.recurrent_state is not None
                                                and self.recurrent_state.draft is not None else None,
                        }
                    )
                elif self.generator.draft_model:
                    if self.generator.mtp_draft:
                        target_hidden = params.get("export_states")[-1]
                        carry_hidden = seq.mtp_carry_hidden
                        if carry_hidden is None:
                            carry_hidden = torch.zeros_like(target_hidden[:, :1, :])
                        shifted_hidden = torch.cat((carry_hidden, target_hidden[:, :-1, :]), dim = 1)
                        seq.mtp_carry_hidden = target_hidden[:, -1:, :].clone()
                        self.mtp_last_hidden = seq.mtp_carry_hidden
                    else:
                        shifted_hidden = None
                    self.generator.draft_model.prefill(
                        input_ids = prefill_ids,
                        params = {
                            "target_hidden": shifted_hidden,
                            "attn_mode": "flash_attn",
                            "block_table": seq.block_index_tensor,
                            "cache": self.generator.draft_cache,
                            "cache_seqlens": torch.tensor([prefill_start], dtype = torch.int32),
                            "indexed_embeddings": self.embeddings if self.generator.mtp_draft else None,
                            "recurrent_states": [self.recurrent_state.draft] if self.recurrent_state is not None
                                                and self.recurrent_state.draft is not None else None,
                        }
                    )

                # Atomic MM prefill may have extended the forward pass past prefill_end, advancing any
                # recurrent state beyond the chunk boundary. The extension is processed again by the
                # next chunk, so rewind to keep the state position in sync with kv_position. Re-fed
                # tokens map to the same state slots with the same values, leaving state content intact.
                if self.recurrent_state is not None and self.recurrent_state.position > prefill_end:
                    self.recurrent_state.rewind_to(prefill_end)

                seq.kv_position = prefill_end

                p2 = min(p1 + 1, len(seq.allocated_pages))
                for local_idx in range(p0, p2):
                    page = seq.allocated_pages[local_idx]
                    page.kv_position = min(max(prefill_end - local_idx * PAGE_SIZE, 0), PAGE_SIZE)
                    if local_idx == 0:
                        page.prev_hash = None
                    else:
                        page.prev_hash = seq.allocated_pages[local_idx - 1].phash
                    pf_a = max(local_idx * PAGE_SIZE, prefill_start)
                    pf_b = min(local_idx * PAGE_SIZE + PAGE_SIZE, prefill_end)
                    pfp_a = pf_a - local_idx * PAGE_SIZE
                    pfp_b = pf_b - local_idx * PAGE_SIZE
                    # The loop runs one page past the chunk; with a chunk ending mid-page
                    # (exact multimodal chunking) that page starts after prefill_end
                    if pfp_b > pfp_a:
                        page.sequence[:, pfp_a:pfp_b].copy_(seq.sequence_ids.torch_slice(pf_a, pf_b))
                    page.can_revert = False

                # A full prompt page that prefill (re)built rather than reusing by hash (the page MTP leaves
                # out of the cached prefix so one real token runs) was allocated under a random hash; give
                # it its content hash now, or every page completed after it chains off the random one and
                # no later checkpoint is findable by a requeued job
                for local_idx in range(p0, p2):
                    page = seq.allocated_pages[local_idx]
                    if page.kv_position == PAGE_SIZE and local_idx < len(seq.page_hashes) \
                            and page.phash != seq.page_hashes[local_idx]:
                        self.hash_completed_page(seq, local_idx)

                progress += prefill_end - prefill_start
                if self.sequences[0].kv_position >= len(seq.sequence_ids) - 1:
                    seq.prefill_complete = True

                if recurrent_last_page:
                    self.maybe_stash_recurrent(self.generator.recurrent_cache, PAGE_SIZE)


        if progress:
            r = {
                "job": self,
                "stage": "prefill",
                "eos": False,
                "curr_progress": sum(seq.kv_position for seq in self.sequences),
                "max_progress": sum(len(seq.sequence_ids) - 1 for seq in self.sequences),
                "serial": self.serial_number,
            }
            if self.identifier is not None:
                r.update({"identifier": self.identifier})
            results.append(r)


    def allocate_pages(self):
        """
        Claim cache pages for this job after it leaves the pending queue.

        The per-sequence page allocation consults the page table hashes prepared by prepare_for_queue(), reviving
        prompt-cache pages where possible and assigning fresh pages for uncached prompt or future generation. For
        recurrent models this also creates or restores the recurrent state corresponding to the cached prefix.
        """

        # Pages matching any of the job's own prompt hashes must not be taken to serve this same allocation's
        # cache misses (e.g. when resuming a partially evicted sequence, the misses at the front must not
        # cannibalize the surviving pages further along the chain)
        protected_hashes = set(self.all_unique_hashes)

        for seq in self.sequences:
            allocated_pages, cached_pages, non_sequential_pages, stashed_recurrent_state = \
                seq.allocate_pages(self.pagetable, self.generator.recurrent_cache, protected_hashes)

            # Free the previous state before acquiring a new one. A bare assignment drops
            # the handle without returning the slot index to the cache free list, so every
            # reallocation (multi-sequence jobs, resumption after eviction) permanently
            # burns a slot; with num_slots == max_batch_size (default 4 on recurrent
            # models) a few such jobs exhaust the pool. The rewind path already does this
            # correctly via free_recurrent_state().
            self.free_recurrent_state()
            if self.generator.recurrent_cache is not None:
                if stashed_recurrent_state is None:
                    self.recurrent_state = self.generator.new_recurrent_state()
                else:
                    self.recurrent_state = self.generator.recurrent_state_from_stashed(
                        stashed_recurrent_state,
                        position = cached_pages * PAGE_SIZE,
                    )
                    self.last_recurrent_checkpoint_pos = self.recurrent_state.position

            # Metrics
            self.cached_pages += cached_pages
            self.total_pages += allocated_pages
            self.non_sequential_pages += non_sequential_pages


    def deallocate_pages(self):
        self.free_recurrent_state()
        for seq in self.sequences:
            if seq.allocated_pages is not None:
                self.pagetable.deallocate_pages(seq.allocated_pages)
                seq.allocated_pages = []


    def prepare_sampling_past_ids(self):
        if not self.sampler.reqs_past_ids:
            return
        n = len(self.sequences[0].sequence_ids)
        if self.pinned_ids is None:
            max_ids = max(len(seq.sequence_ids) for seq in self.sequences) + self.max_new_tokens + 8
            self.pinned_ids = torch.empty((1, max_ids), dtype = torch.long, pin_memory = True)
            self.pinned_ids_valid = 0
        # The sequence only grows by appending or shrinks by truncation (which clamps the
        # watermark), so the buffer is valid below the watermark and only the tail is staged
        if self.pinned_ids_valid < n:
            self.pinned_ids[:, self.pinned_ids_valid : n].copy_(
                self.sequences[0].sequence_ids.torch_slice(self.pinned_ids_valid, n)
            )
            self.pinned_ids_valid = n
        self.current_pinned_ids = self.pinned_ids[:, :n]
        self.current_device_ids = self.current_pinned_ids.to(self.logits_device, non_blocking = True)


    def activate(self):
        """
        Mark the job active and initialize sampling filters.
        """
        self.logits_device = self.generator.model.output_device
        if not self.is_requeued:
            for f in self.filters:
                f.attach(self)
                f.reset()
                f.is_active = f.trigger_token is None and not self.filters_suspended


    def is_checkpoint_boundary(self, override_interval = None):
        """
        Return whether the current sequence position should stash a recurrent checkpoint.

        Checkpoints sit on page boundaries, spaced at least the checkpoint interval apart: a position qualifies
        once it is the interval or more past the previous checkpoint, or past the end of the cached K/V prefix
        (which a restored state matches) while there is none. Positions are not required to fall on a fixed grid,
        so prefill chunks may vary in size. An explicit interval overrides the normal policy; otherwise prefill
        uses the coarser prompt-ingestion interval until it nears the generation boundary, where it switches to
        the normal recurrent checkpoint interval.
        """
        seq = self.sequences[0]
        seq_pos = seq.kv_position
        if seq_pos % PAGE_SIZE:
            return False
        if override_interval:
            return seq_pos % override_interval == 0
        prompt_len = len(seq.sequence_ids) - 1
        if seq_pos >= prompt_len - self.generator.max_chunk_size * 2:
            interval = self.generator.recurrent_checkpoint_interval
        else:
            interval = self.generator.recurrent_checkpoint_interval_pp
        anchor = self.last_recurrent_checkpoint_pos
        if anchor is None:
            anchor = self.cached_pages * PAGE_SIZE
        return seq_pos - anchor >= interval


    def mm_exact_spans(self, seq):
        """Prompt positions [start, end) of each embedding's non-causal span (its rows from
        align_lead on, i.e. IMAGE_START .. IMAGE_END for DeepSeek-V4), ascending. Computed once:
        the prompt never moves."""
        spans = getattr(self, "_mm_exact_spans", None)
        if spans is None:
            ids = seq.sequence_ids.torch()[0]
            spans = []
            for e in self.embeddings:
                lo, hi = e.first_index + getattr(e, "align_lead", 0), e.last_index
                pos = torch.nonzero((ids >= lo) & (ids < hi)).flatten()
                if pos.numel():
                    spans.append((int(pos[0]), int(pos[-1]) + 1))
            spans.sort()
            self._mm_exact_spans = spans
        return spans

    def maybe_stash_recurrent(self, cache, interval = None):
        """
        Store the current recurrent state if the sequence is at a checkpoint boundary.
        """
        seq = self.sequences[0]

        if seq.kv_position == 0:
            return

        if self.is_checkpoint_boundary(interval) and \
            self.last_recurrent_checkpoint_pos != seq.kv_position:
            assert seq.kv_position % PAGE_SIZE == 0

            self.last_recurrent_checkpoint_pos = seq.kv_position
            last_page = (seq.kv_position - 1) // PAGE_SIZE

            page = seq.allocated_pages[last_page]
            assert page.kv_position == PAGE_SIZE
            cache.put(page.phash, self.recurrent_state)

            # Prevent setting the same checkpoint twice in a row if prefill ends on the first page of a chunk
            self.last_recurrent_checkpoint_pos = seq.kv_position


    def find_recurrent_stash(self, target_pos: int):
        """
        Return the most recent page-aligned recurrent state stash at or before target_pos, refreshing its LRU
        position in the recurrent cache, or None if no eligible stash remains.
        """
        seq = self.sequences[0]
        rc = self.generator.recurrent_cache
        for pi in range(target_pos // PAGE_SIZE - 1, -1, -1):
            stashed = rc.get_stashed(seq.allocated_pages[pi].phash)
            if stashed is not None and stashed["position"] == (pi + 1) * PAGE_SIZE:
                return stashed
        return None


    def free_recurrent_state(self):
        if self.recurrent_state is not None:
            self.recurrent_state.free()
            self.recurrent_state = None


    def suffix_match(self, seq: torch.Tensor):
        """(begin, end) of the earlier occurrence of the longest suffix of seq found by the job's suffix
        automaton; end - begin is the match length. The automaton only accepts new tokens, so a second query
        over the same sequence in one round (n-gram draft, then hybrid draft) reuses the first answer"""
        n = seq.shape[-1]
        if self.sam_match is not None and self.sam_match[0] == n:
            return self.sam_match[1], self.sam_match[2]
        beg, end = self.sam.accept_tensor(seq)
        self.sam_match = (n, beg, end)
        return beg, end


    def get_hybrid_draft(self, length: int):
        """
        Continuation of the longest suffix match for the hybrid draft: (tokens, match length), with up to
        `length` tokens following the earlier occurrence of the match. The caller decides whether the match
        is long enough.
        """
        assert self.sam
        seq = self.sequences[0].sequence_ids.torch()
        beg, end = self.suffix_match(seq)
        if end <= beg:
            return torch.empty((1, 0), dtype = torch.long), 0
        # The match sits `lag` tokens behind the present, so the continuation in the buffer is at most that
        # long. A match longer than its lag means the sequence is periodic over it ("A B C A B C A B"), and the
        # same rule that found it (x[n] = x[n - lag]) extends the continuation past the buffer by repeating
        # the lag window; a match against distant context has a lag beyond `length` and tiles nothing
        cont = seq[:, end:]
        lag = cont.shape[-1]
        if lag < length:
            cont = cont.repeat(1, -(-length // lag))
        return cont[:, :length], end - beg


    def get_ngram_draft(self, draft_length: int):
        """
        Return the continuation of the longest live/corpus suffix match.
        """
        assert self.sam

        # Update SAM with current history and find longest suffix
        seq = self.sequences[0].sequence_ids.torch()
        beg, end = self.suffix_match(seq)

        # Grab continuation after longest match or return empty seq
        if end - beg >= self.generator.ngram_match_min:
            draft = seq[:, end : end + draft_length]
        else:
            draft = torch.empty((1, 0), dtype = torch.long)

        if self.corpus_cursor is not None:
            matched, corpus_draft = self.corpus_cursor.draft(seq, self.generator.ngram_match_min, draft_length)
            # Prefer live context on ties; an exhausted occurrence offers no draft.
            if corpus_draft.numel() and (not draft.numel() or matched > end - beg):
                draft = corpus_draft
        return draft
