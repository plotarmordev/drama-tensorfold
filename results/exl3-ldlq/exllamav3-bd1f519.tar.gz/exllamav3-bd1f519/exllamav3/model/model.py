from __future__ import annotations
from functools import cached_property
from typing import Callable
import gc
import torch
from .config import Config
from ..util import parse_int_list
from ..util.memory import free_mem
from .model_tp import Model_TPMixin
from .model_ls import Model_LSMixin
from ..util.tensor import g_tensor_cache
from ..cache.recurrent_util import advance_recurrent_states

class Model(Model_TPMixin, Model_LSMixin):

    def __init__(
        self,
        config: Config,
        **kwargs,
    ):
        super().__init__()
        self.config = config

        self.modules = []
        self.fwd_modules = []
        self.caps = {
            "supports_tp": True
        }
        self.active_devices = []
        self.output_device = None
        self.cache_weakrefs = {}
        self.recurrent_state_cls = None
        self.draft_verifier_params = {}

        # Index of last layer that affects KV cache, used during prefill
        self.last_kv_module_idx = None
        self.last_kv_module_idx_instance = None
        self.logit_layer_idx = None
        self.first_block_idx = None

        # Calibration options
        self.calibration_all_experts = False

        # Modules dict
        self.modules_dict = None

        # Check compatibility
        self.check_compat()


    def __iter__(self):
        for module in self.modules:
            yield from module


    def find_module(self, key: str):
        if self.modules_dict is None:
            self.modules_dict = {module.key: module for module in self}
        return self.modules_dict[key]


    @cached_property
    def _get_cache_layers(self):
        return [m for m in self if m.caps.get("kv_cache")]
    def get_cache_layers(self):
        return self._get_cache_layers


    @cached_property
    def _get_recurrent_layers(self):
        return [m for m in self if m.caps.get("recurrent_cache")]

    def get_recurrent_layers(self):
        return self._get_recurrent_layers

    @cached_property
    def _get_prefetch_layers(self):
        # modules that stage input-dependent data (PLE n-gram rows) on a worker thread before the
        # first layers are issued, so the gather overlaps block 0 instead of stalling at its layer
        return [m for m in self if m.caps.get("prefetch_ids")]


    def prefetch_tokens(self, ids: list[int]):
        """
        Tokens the next forward pass will embed, known ahead of it (the generator has just
        sampled them). An embedding table streamed from disk starts reading their rows, so the
        read overlaps the host work before that forward instead of stalling it.
        """
        if not self.loaded_tp and self.modules:
            prefetch = getattr(self.modules[0], "prefetch_tokens", None)
            if prefetch is not None:
                prefetch(ids)


    def get_layer_instances(self, layer_idx):
        if not self.config.layer_map:
            return [(layer_idx, 0)]
        return [
            (layer_idx, instance)
            for instance in range(self.config.layer_map.count(layer_idx))
        ]


    def num_unmapped_layers(self):
        indices = set()
        for m in self.modules:
            if m.layer_idx is not None:
                assert m.layer_idx not in indices
                indices.add(m.layer_idx)
        assert len(indices) == max(indices) + 1
        return len(indices)


    def prepare_layer_map(self):
        """
        Prepare list of (module, instance_num, original_idx) for mapped layers
        """

        # Parse layer map string
        if self.config.layer_map is None and self.config.layer_map_str:
            self.config.layer_map = parse_int_list(
                self.config.layer_map_str,
                min_value = 0,
                max_value = self.num_unmapped_layers() - 1
            )

        # No layer map
        if not self.config.layer_map:
            self.fwd_modules = [(m, 0, idx) for idx, m in enumerate(self.modules)]
            self.last_kv_module_idx_instance = (self.last_kv_module_idx, 0)
            return

        # Isolate and enumerate indexed layers
        prolog = []
        inner = []
        epilog = []
        for m in self.modules:
            if m.layer_idx is None:
                if not inner:
                    prolog.append(m)
                else:
                    epilog.append(m)
            else:
                assert len(inner) == m.layer_idx, "Inner layers are not in order"
                assert not epilog, "Inner layers are not consecutive"
                inner.append(m)

        # Compile relayered list
        relayered = []
        inner_count = [0] * len(inner)
        offset = 0
        for idx, m in enumerate(prolog):
            relayered.append((m, 0, idx + offset))
        offset = len(prolog)
        for idx in self.config.layer_map:
            relayered.append((inner[idx], inner_count[idx], idx + offset))
            inner_count[idx] += 1
        offset = len(prolog) + len(inner)
        for idx, m in enumerate(epilog):
            relayered.append((m, 0, idx + offset))

        self.fwd_modules = relayered
        if self.last_kv_module_idx is not None:
            self.last_kv_module_idx_instance = (
                self.last_kv_module_idx,
                inner_count[self.last_kv_module_idx - len(prolog)] - 1
            )


    @staticmethod
    def from_config(
        config: Config,
        component: str = "text",
        **kwargs
    ):
        """
        Create model instance from config

        :param config:
            Config created with Config.from_directory()

        :param component:
            Which component model to load, for models with multiple component.
        """

        assert component in config.model_classes, \
            f"{config.architecture} does not define a '{component}' component model"

        model = config.model_classes[component](config, **kwargs)
        model.component = component

        # Compile layer map after model is constructed (before any caches are attached)
        model.prepare_layer_map()
        return model


    def prepare_inputs(self, input_ids: torch.Tensor, params: dict) -> torch.Tensor:
        # Overridden by model arch class
        raise NotImplementedError()


    @torch.inference_mode
    def warmup(
        self,
        cache = None,
        max_chunk_size: int = 2048,
        max_batch_size: int = 8,
        max_q_len: int = 16,
        long_context: bool = True,
        progressbar: bool = False,
        callback: Callable[[int, int], None] | None = None,
        verbose: bool = False,
    ) -> list[str]:
        """
        Pay the first-use costs of the model's hot paths up front, instead of on the first user requests:
        Triton kernel compilation and autotuning, the cooperative GEMM autotuner, and the static workspaces
        of the graph-captured decode paths. Runs a short schedule of real forward passes through the loaded
        model (layer-split or tensor-parallel alike):

          - single rows at 1, 2, 4, 8, 16, 32, 48 and 64 tokens: the GEMM autotuner keys on the row count only up
            to the 64-row bucket, so these passes cover every tuned shape of every quantized projection
          - one full chunk (prefill kernels, MoE prefill paths)
          - a batched family (max_batch_size rows): a short prefill, a one-token decode step and a multi-token
            step with recurrent history (draft/MTP verification shapes), then the same at batch size 1
          - one long-context family, when the cache is large enough: a chunk of prefill followed by a short
            step and a decode step past it, so sparse-attention regimes (DSA/QSA selection) compile too

        In tensor-parallel mode every rank runs the passes on its own with the collectives stubbed out, so ranks
        compile concurrently and a rank that is cold-compiling can never hold the others in a reduce past its
        sync deadline. The values computed by warmup passes are meaningless.

        Call this once after load() and BEFORE attaching a Generator to the cache (or pass a cache the generator
        does not use): the passes write into the cache's leading pages and temporarily take recurrent-state
        slots. Draft models (MTP/DFlash) are skipped; the generator's own draft passes warm those.

        :param cache:
            Cache to run the cached passes on. Defaults to the first cache attached to the model. Without any
            cache, only the cache-less single-row and chunk passes run.

        :param max_chunk_size:
            Longest prefill to exercise (the model's max_chunk_size)

        :param max_batch_size:
            Batch size of the batched decode family (bounded by the cache size)

        :param max_q_len:
            Longest decode step (bounded by the cache's max_history for recurrent models)

        :param long_context:
            Include the long-context family

        :return:
            Labels of the passes that raised (each is reported and skipped; the rest still run)
        """
        from ..constants import PAGE_SIZE
        from ..util.progress import ProgressBar
        import random, time

        if any(self.caps.get(c) for c in ("mtp_draft", "dflash_draft", "dflash2_draft")):
            return []
        if cache is None:
            for ref in self.cache_weakrefs.values():
                c = ref()
                if c is not None:
                    cache = c
                    break

        vocab = self.config.vocab_size
        recurrent = len(self.get_recurrent_layers()) > 0
        rng = random.Random(0)
        def ids(b, n):
            return torch.tensor([[rng.randrange(vocab) for _ in range(n)] for _ in range(b)], dtype = torch.long)

        # Families: (label, bsz, cache rows per sequence (multiple of PAGE_SIZE), [(q_len, history), ...]).
        # Steps of a family share recurrent states and advance the position; each family starts at 0
        families = []
        if cache is None:
            for n in (1, 2, 4, 8, 16, 32, 48, 64, max_chunk_size):
                families.append((f"rows {n}", 1, None, [(n, False)]))
        else:
            cap = cache.max_num_tokens
            def rup(n):
                return -(-n // PAGE_SIZE) * PAGE_SIZE
            chunk = min(max_chunk_size, cap)
            for n in (1, 2, 4, 8, 16, 32, 48, 64):
                if rup(n) <= cap:
                    families.append((f"rows {n}", 1, rup(n), [(n, False)]))
            if chunk > 16:
                families.append((f"chunk {chunk}", 1, rup(chunk), [(chunk, False)]))
            # Multi-token steps beyond the recurrent history the cache reserves would assert
            q_hist = min(max_q_len, cache.max_history + 1)
            pre = min(32, PAGE_SIZE - max_q_len - 2)
            steps = [(pre, False), (1, False)] + ([(q_hist, True)] if q_hist > 1 else [])
            bsz = min(max_batch_size, cap // PAGE_SIZE)
            # Recurrent models take one state slot per sequence; the cache's slot pool (its
            # max_batch_size) bounds the batched family
            if recurrent:
                bsz = min(bsz, len(cache.free_list))
            if bsz > 1:
                families.append((f"batch {bsz} decode", bsz, PAGE_SIZE, steps))
            families.append(("batch 1 decode", 1, PAGE_SIZE, steps))
            if long_context and chunk > 16:
                span = rup(chunk + 64 + 1 + max_q_len)
                if span <= cap:
                    families.append((f"long context {chunk}", 1, span, [(chunk, False), (64, False), (1, False)]))

        failures = []
        n_passes = sum(len(f[3]) for f in families)
        done = 0
        t0 = time.time()
        with ProgressBar("Warmup" if progressbar else None, n_passes) as progress:
            for label, bsz, seq_cap, steps in families:
                states = None
                pos = 0
                # Take the family's recurrent-state slots up front (all or nothing) so a shortage
                # never strands a slot: prepare_for_recurrence creates them one by one and would
                # leak the ones it took before running out
                if recurrent and cache is not None:
                    if len(cache.free_list) < bsz:
                        print(f" !! Warmup: skipping {label}, only {len(cache.free_list)} recurrent-state slot(s) free")
                        done += len(steps)
                        progress.update(done)
                        continue
                    states = [cache.get_new_state() for _ in range(bsz)]
                for q, history in steps:
                    params = {"tp_warmup": True}
                    if cache is None:
                        params["attn_mode"] = "flash_attn_nc"
                    else:
                        params.update({
                            "attn_mode": "flash_attn",
                            "cache": cache,
                            "batch_shape": (bsz, seq_cap),
                            "past_len": pos,
                        })
                        if states is not None:
                            params["recurrent_states"] = states
                        if history:
                            params["recurrent_history"] = True
                    # Chunk-class steps stop the head at the last row, like prefill does (the
                    # generator never takes logits for a whole chunk): full-chunk logits are the
                    # single largest transient of the whole load (1.9 GiB fp16 at 4096 rows on a
                    # 248k vocab) and would set the process's reserved high-water mark for nothing
                    if q > 16:
                        params["last_tokens_only"] = 1
                    step_label = f"{label}, {q} token(s) at {pos}" if cache is not None else label
                    try:
                        self.forward(ids(bsz, q), params)
                        states = params.get("recurrent_states")
                        pos += q
                    except Exception as e:
                        failures.append(step_label)
                        print(f" !! Warmup pass failed ({step_label}): {e!r}")
                        break
                    finally:
                        done += 1
                        progress.update(done)
                        if callback: callback(done, n_passes)
                if states:
                    for r in states:
                        cache.release_state(r)
        if verbose:
            print(f" -- Warmup: {n_passes - len(failures)}/{n_passes} passes in {time.time() - t0:.2f} s")
        return failures


    @torch.inference_mode
    def prefill(self, input_ids: torch.Tensor, params: dict | None = None):
        """
        Run prompt-prefill inference and update cache/recurrent state.

        Inputs are first normalized by the architecture-specific prepare_inputs() hook. If the model is loaded in
        tensor-parallel mode, execution is dispatched through prefill_tp(), which fans the work out to TP workers
        and stops at the last module that affects K/V cache state. Otherwise the layer-split path prefill_ls() runs
        directly in the current process. Both paths advance recurrent states after the forward work completes.
        """
        if params is None:
            params = {}
        x = self.prepare_inputs(input_ids, params)
        if self.loaded_tp:
            y = self.prefill_tp(x, params, self.last_kv_module_idx, self.modules)
            advance_recurrent_states(input_ids, params, self)
            return y
        else:
            for m in self._get_prefetch_layers:
                m.prefetch(x, params)
            y = self.prefill_ls(x, params)
            advance_recurrent_states(input_ids, params, self)
            return y


    @torch.inference_mode
    def lm_head_argmax(self, state: torch.Tensor, params: dict) -> torch.Tensor:
        """
        Greedy token per position from a hidden state through this model's LM head, for drafters
        that borrow the target's head (MTP, DFlash). Works in both layer-split and tensor-parallel
        mode. With params["export_draft_conf"], also exports the winning logit per position as
        params["draft_conf"], which the generator's confidence-calibrated draft sizing consumes.
        The vocabulary is cropped to the unpadded size in both modes, so a zero-initialized
        padding column can never win.
        """
        export = bool(params.get("export_draft_conf"))
        if self.loaded_tp:
            state = self.tp_producer.send(state)
            ids, conf = self.tp_dispatch_lm_head_argmax((state, {}), return_max = True)
            if export:
                params["draft_conf"] = conf
            return ids
        lm = self.modules[self.logit_layer_idx]
        # Draft-only sparse subset of the vocabulary, selected by the caller through params so the
        # verification forward can never take it
        sh = lm.sparse_head
        flag = params.get("sparse_head") if sh is not None else None
        if flag is True and sh.ready:
            ids, conf, emb = sh.argmax(lm.prepare_for_device(state, params), embedding = True)
            if export:
                params["draft_conf"] = conf
            if emb is not None:
                params["draft_embedding"] = emb
            return ids
        logits = lm.forward(lm.prepare_for_device(state, params), params)
        logits = logits[..., :self.config.vocab_size]
        if flag == "probe":
            # Probe round: full head answers, the sparse pick is recorded alongside for the drift statistics
            full_ids = torch.argmax(logits, dim = -1)
            sparse_ids, _ = sh.argmax(lm.prepare_for_device(state, params))
            sh.record_probe(full_ids, sparse_ids)
        if export:
            conf, ids = torch.max(logits, dim = -1)
            params["draft_conf"] = conf
            return ids
        return torch.argmax(logits, dim = -1)


    @torch.inference_mode
    def forward(self, input_ids: torch.Tensor, params: dict | None = None):
        """
        Run a normal model forward pass for generation or verification.

        After architecture-specific input preparation, tensor-parallel models dispatch through forward_tp() so each
        worker processes its shard and gathers outputs as needed. Non-TP models use the local layer-split forward
        path forward_ls(). Recurrent state advancement is shared between the two modes and runs after the selected
        forward path returns.
        """
        if params is None:
            params = {}
        x = self.prepare_inputs(input_ids, params)
        if self.loaded_tp:
            y = self.forward_tp(x, params, self.last_kv_module_idx, self.modules)
            advance_recurrent_states(input_ids, params, self)
            return y
        else:
            for m in self._get_prefetch_layers:
                m.prefetch(x, params)
            y = self.forward_ls(x, params)
            advance_recurrent_states(input_ids, params, self)
            return y


    def unload(self):
        for module in self.modules:
            module.unload()
        # The loader's open slab blocks must not outlive the tensors sliced from them
        self.config.stc.release_arena()
        self.active_devices = []
        self.unload_tp()
        self.output_device = None
        # Attached caches lose their layer tensors with the modules that allocated them
        for ref in self.cache_weakrefs.values():
            cache = ref()
            if cache is not None:
                cache.initialized = False


    def load_gen(
        self,
        device: torch.device | str | int | None = None,
        tp_output_device: torch.device | str | int | None = None,
        reserve_per_device: list[float] | float | None = None,
        use_per_device: list[float] | float | None = None,
        tensor_p: bool = False,
        progressbar: bool = False,
        max_chunk_size: int = 2048,
        max_output_size: int = 32,
        max_output_factor: int = 1,
        callback: Callable[[int, int], None] | None = None,
        generator: bool = True,
        tp_dev_limits: dict | None = None,
        tp_backend: str = "native",
        verbose: bool = False,
        max_batch_size: int = 1,
        tp_options: dict | None = None,
        autosplit_no_forward: bool = False,
        draft_model: Model | None = None,
        attn_device: torch.device | str | int | None = None,
    ):
        """
        Load model, generator function. For regular function, call load() with the same arguments

        :param device:
            (optional) If specified, load to single device, e.g. "cuda:0"

        :param tp_output_device:
            (optional) If loading with tensor_p == True, device on which to gather output logits. Must be one of
            the active devices in the split. Default is first device in split

        :param reserve_per_device:
            (optional) Amount of memory to reserve for any device. Either a value in GB to apply on all devices
            or a list of floats giving an individual reserve per device. Negative reserve excludes device from
            split. E.g.:

            # reserve 4.5 GB on cuda:0, 1 GB on each cuda:1 and on cuda:2
            model.load(reserve_per_device = [4.5, 1, 1])

            # reserve 1 GB on cuda:0 and cuda:2, exclude cuda:1
            model.load(reserve_per_device = [1, -1, 1])

            The default reserve per device is 0.5 GB. This applies to devices not included in reserve_per_device
            as well.

        :param use_per_device:
            (optional) Amount of memory to use per device.

            Does not account for memory allocated by other processes or by the calling process up to the call
            to model.load(), i.e. if cuda:0 currently has 3 GB in use and user_per_device = [12, ...], at the
            end of loading cuda:0 will have up to 15 GB of VRAM allocated, using up to 15 GB during a forward
            pass.

            Devices not included in use_per_device, or included with a value of 0, will not be used, e.g.:

            # use up to 23 GB on cuda:0 and cuda:2, do not load on cuda:1 and cuda:3 (if present)
            model.load(use_per_device = [23, 0, 23])

        :param tensor_p:
            Load in tensor-parallel mode. By default, attempt to split model according to available VRAM.
            Allocation can be overridden with use_per_device or modified by reserve_per_device.

        :param max_chunk_size:
            The maximum number of tokens to expect in a single forward pass. Informs the layer split only, and
            makes no difference when loading on a single device.

        :param max_output_size:
            The maximum number of output tokens to expect in a single forward pass. Informs the estimate of the
            size of the output logits. Values larger than max_chunk_size have no effect.

        :param max_output_factor:
            When estimating the memory footprint of the output layer, scale the size of the output tensor by
            this factor. For instance, if the first thing you wish to do with a float16 output tensor is upcast
            to float32, a value of 3 here would (attempt to) make sure the output layer always ends up on a
            device where there is enough space for that.

        :param progressbar:
            Show rich progressbar while loading

        :param callback:
            If provided, called with (current_module, num_modules) for every module loaded. Don't specify a
            callback function when using the

        :param generator:
            Always true when using the _gen function directly

        :param tp_dev_limits:
            (optional, TP only) Dictionary of module categories and max parallelism for each. Categories are
            "mlp", "attn", "moe", "linear" (i.e. output layer). Example:
            tp_dev_limits = {
                "attn": 2,  # Each attn layer uses at most two devices for tensor parallelism
                "moe": 3,  # etc.
            }

        :param tp_backend:
            str, either "nccl" (default) or "native"

        :param verbose:
            bool, more info while loading including full TP split

        :param max_batch_size:
            Max batch size to account for when loading in autosplit mode (default: 1)

        :param tp_options:
            dict of optional values:
                "moe_tensor_split": bool - use tensor split rather than expert parallelism for MoE layers

        :param autosplit_no_forward:
            For debug purposes, skip reference forward pass during autosplit load.

        :param draft_model:
            (optional) Draft model that will verify against this model. Loaded first, except when its caps say
            load_with_target: such a drafter (the Gemma4 assistant) reads this model's cache layers in place and
            cannot load on its own; its modules are loaded here, each on the device of the layer it reads (see
            its modules_with_target), within the same budget. When the drafter taps hidden states of this model
            (DFlash), the copies of the tapped layers' states stay resident on their devices for the whole
            forward, and the split budgets for them.

        :param attn_device:
            (optional, split load) Device for the modules the architecture pins together (caps["attn_device"]:
            the attention layers of DeepSeek-V4.1, whose layers read K/V pools and index selections owned by
            earlier layers, so a layer split cannot place them per layer). They load there first, every other
            module splits over the remaining budget, and a block whose attention sits elsewhere moves the
            attention input and output across. Default: the first device of the split
        """

        if self.caps.get("load_with_target"):
            raise RuntimeError(
                f"{self.config.architecture} loads with its target model: pass it as draft_model to the target's "
                f"load() instead of loading it on its own"
            )
        attached = None
        if draft_model is not None and draft_model.caps.get("load_with_target"):
            if tensor_p:
                raise NotImplementedError(
                    f"{draft_model.config.architecture} drafting is not currently implemented for tensor-parallel "
                    f"targets: the drafter reads the target's K/V cache layers, which a TP load shards across devices"
                )
            draft_model.attach_to(self)
            attached = draft_model.modules_with_target(self)

        # The pass is there to hand back VRAM held by garbage from an earlier model. With nothing
        # allocated on any device yet (the usual first load) there is none, and a full collection
        # walks every object imported so far
        if any(torch.cuda.memory_allocated(i) for i in range(torch.cuda.device_count())):
            free_mem()

        # Objects alive at this point (everything imported, any earlier model) are frozen for the
        # duration of the load: they cannot become garbage because of it, and without the freeze
        # every automatic collection during the load, and the collection in free_mem() below, walks
        # them all over again. Skipped when the caller keeps its own frozen set
        freeze = gc.get_freeze_count() == 0
        if freeze:
            gc.freeze()
        try:
            # Route CPU-offloaded MoE layers to this component's own worker and budget (an MTP head
            # shares the config but loads after the main model's worker has already started)
            self.config.infer_params.moe_cpu_component = getattr(self, "component", "text")

            # CPU-offloaded experts: start the worker process now, so its own startup (the
            # interpreter, torch, the checkpoint index) overlaps the first modules' loading
            # instead of holding up the first offloaded layer. It idles if no layer ends up
            # offloaded; unload shuts it down either way
            ip = self.config.infer_params
            if int(getattr(ip, "moe_cpu_split", 0) or 0) or int(getattr(ip, "moe_cpu_offload", 0) or 0):
                from .moe_cpu_host import MoeCpuHost
                MoeCpuHost.for_config(self.config)._spawn()

            assert not (bool(reserve_per_device) and bool(use_per_device)), \
                "Cannot specify both memory usage and memory reserve."

            assert max_chunk_size >= 1, "max_chunk_size must be positive"
            assert max_output_size >= 1, "max_output_size must be positive"
            assert max_output_factor >= 1, "max_output_factor must be positive"

            # Load to single device
            if device is not None:
                assert not bool(reserve_per_device) and not bool(use_per_device), \
                    "Cannot specify reserve_per_device or use_per_device when loading to single device."
                assert not tensor_p, \
                    "Cannot use tensor_p when loading to single device."
                self._load_single(progressbar, device, self.config, self.modules, verbose, attached)
                self.output_device = self.modules[-1].device

            # Use/reserve
            else:
                rpd = reserve_per_device is not None
                upd = use_per_device is not None
                assert not (rpd and upd), \
                    "Cannot specify both reserve_per_device or use_per_device."
                num_devices = torch.cuda.device_count()

                if not upd:
                    if reserve_per_device is None:
                        reserve_per_device = [0.5] * num_devices
                    elif any(isinstance(reserve_per_device, t) for t in [float, int]):
                        reserve_per_device = [reserve_per_device] * num_devices
                    elif not isinstance(reserve_per_device, list):
                        raise ValueError("reserve_per_device must be float or list[float]")
                    while len(reserve_per_device) < num_devices:
                        reserve_per_device.append(0.5)
                    reserve_per_device = [int(x * 1024**3) for x in reserve_per_device]
                    active_devices = [
                        i for i in range(num_devices)
                        if i >= len(reserve_per_device) or reserve_per_device[i] >= 0
                    ]

                if upd:
                    if any(isinstance(use_per_device, t) for t in [float, int]):
                        use_per_device = [use_per_device] * num_devices
                    elif not isinstance(use_per_device, list):
                        raise ValueError("use_per_device must be float or list[float]")
                    use_per_device = [int(x * 1024**3) for x in use_per_device]
                    active_devices = [
                        i for i, x in enumerate(use_per_device)
                        if x > 0
                    ]

                # Split load
                if not tensor_p:
                    yield from self._load_autosplit(
                        progressbar,
                        reserve_per_device,
                        use_per_device,
                        active_devices,
                        max_chunk_size,
                        max_output_size,
                        max_output_factor,
                        callback,
                        generator,
                        self.config,
                        self.modules,
                        verbose,
                        max_batch_size,
                        self.cache_weakrefs,
                        autosplit_no_forward,
                        draft_model.draft_verifier_params.get("export_state_layers") if draft_model else None,
                        attached,
                        attn_device,
                    )
                    self.output_device = self.modules[-1].device

                # Tensor-P load:
                else:
                    if not self.caps.get("supports_tp"):
                        raise NotImplementedError(f"Tensor-parallel is not currently implemented for {self.config.architecture}")
                    if self.config.layer_map:
                        raise NotImplementedError(f"Tensor-parallel is not currently implemented for relayered models.")
                    # CPU expert offload hooks into a module's load onto a CUDA device. The TP loader
                    # stages modules on the CPU and the workers rebuild them from the export, so a
                    # requested offload would be dropped without notice and every expert would land
                    # in VRAM
                    ip = self.config.infer_params
                    cpu_modes = [name for name, value in (
                        ("moe_cpu_split", getattr(ip, "moe_cpu_split", 0)),
                        ("moe_cpu_offload", getattr(ip, "moe_cpu_offload", 0)
                            if getattr(self, "component", "text") == "text"
                            else getattr(ip, "draft_moe_cpu_offload", 0)),
                    ) if value]
                    if cpu_modes:
                        raise NotImplementedError(
                            f"CPU expert offload ({', '.join(cpu_modes)}) is not currently implemented for "
                            f"tensor-parallel loads; use layer-split mode or disable the offload."
                        )

                    if tp_output_device is None:
                        tp_output_device = active_devices[0]
                    else:
                        assert torch.device(tp_output_device).index in active_devices, \
                            "Output device must be part of split."

                    if tp_options is None:
                        tp_options = {}

                    yield from self._load_tp(
                        progressbar,
                        reserve_per_device,
                        use_per_device,
                        active_devices,
                        max_chunk_size,
                        max_output_size,
                        max_output_factor,
                        callback,
                        generator,
                        tp_output_device,
                        self.config,
                        self.modules,
                        tp_dev_limits,
                        tp_backend,
                        verbose,
                        tp_options,
                    )
                    self.output_device = tp_output_device

            free_mem()

            # Release all global shared tensors (refs still held by modules until model is unloaded)
            g_tensor_cache.drop_all()

            # Mark every attached cache usable.
            self._mark_caches_initialized()
            # A drafter loaded alongside: finished the way its own load would have
            if attached is not None:
                draft_model.output_device = draft_model.modules[-1].device
                draft_model._mark_caches_initialized()
        finally:
            if freeze:
                gc.unfreeze()


    def _mark_caches_initialized(self):
        for ref in self.cache_weakrefs.values():
            cache = ref()
            if cache is not None:
                cache.initialized = True


    @torch.inference_mode
    def load(self, *args, **kwargs):
        """
        Load as a regular function, see arguments for load_gen().
        """

        kwargs["generator"] = False
        f = self.load_gen(*args, **kwargs)
        for _ in f: pass

        # CPU-offloaded MoE experts: make sure the worker processes are up before the first
        # forward (spawned during module loading when the offload count is exact, so the child's
        # weight loading overlaps the parent's; started here otherwise). ensure_started is
        # idempotent, so already-running workers of other components are unaffected
        for host in getattr(self.config, "moe_cpu_hosts", {}).values():
            host.ensure_started()


    def get_layout_tree(self, pre_indent: int) -> str:
        def get_branch(module, b_indent) -> str:
            nonlocal pre_indent
            lines = [get_branch(m, b_indent + 4) for m in module.modules]
            dedup_lines = []
            count = 1
            for i in range(len(lines)):
                if i < len(lines) - 1 and lines[i] == lines[i + 1]:
                    count += 1
                else:
                    pref = ""
                    if count > 1:
                        pref = f"[{count}x] "
                        count = 1
                    dedup_lines.append(lines[i].replace("[]", pref))
            r = " " * (pre_indent + b_indent) + " - []" + module.get_name() + "\n"
            r += "".join(dedup_lines)
            return r

        def compact_rle(s: list[str]) -> list[tuple[int, list[str]]]:
            n = len(s)
            if n == 0:
                return []
            dp = [(0, None)] + [(float('inf'), None)] * n
            for i in range(1, n + 1):
                for j in range(i - 1, -1, -1):
                    seg = s[j:i]
                    seg_len = len(seg)
                    p = _smallest_period(seg)
                    if p is not None:
                        k = seg_len // p
                        cost = dp[j][0] + p
                        if cost < dp[i][0]:
                            dp[i] = (cost, (j, k, s[j:j + p]))
            result = []
            pos = n
            while pos > 0:
                _, (j, k, pattern) = dp[pos]
                result.append((k, pattern))
                pos = j
            result.reverse()
            return result

        def _smallest_period(seg: list[str]) -> int | None:
            n = len(seg)
            for p in range(1, n + 1):
                if n % p == 0 and all(seg[i] == seg[i % p] for i in range(p, n)):
                    return p
            return None

        br = get_branch(self, 0).replace("[]", "").rstrip()
        br = br.split("\n")
        cbr = compact_rle(br)
        br = []
        for num, span in cbr:
            if num == 1:
                br += span
            else:
                br += [" " * span[0].index("- ") + f"- [{num}x]"]
                br += ["    " + s for s in span]

        return "\n".join(br)


    def get_storage_info(self):
        from ..modules import Linear
        def get_tensor_size(tensors):
            return 8 * sum(t.element_size() * t.numel() for t in tensors.values())
        sum_bits = 0
        sum_numel = 0
        head_bpw = 0
        head_numel = 0
        for module in self:
            if module.key.endswith("lm_head"):
                if module.device is not None:
                    head_bpw = get_tensor_size(module.get_tensors()) / module.weights_numel()
                else:
                    head_bpw = sum(self.config.stc.get_tensor_sizes(module.key)) / module.weights_numel() * 8
                head_numel = module.weights_numel()
            elif isinstance(module, Linear):
                if module.device is not None:
                    sum_bits += get_tensor_size(module.get_tensors())
                else:
                    sum_bits += sum(self.config.stc.get_tensor_sizes(module.key)) * 8
                sum_numel += module.weights_numel()
        vram_bits = head_numel * head_bpw + sum_bits
        return sum_bits / sum_numel, head_bpw, vram_bits


    def get_name(self):
        return self.__class__.__name__


    @staticmethod
    def get_additional_compiled_tensors(config: Config):
        return {}


    def default_chat_prompt(self, prompt: str, system_prompt: str = None) -> str:
        """
        Convenience function for formatting a single chat request with the default template associated with the
        model's architecture, to simplify example and test scripts. Doesn't consider the model's actual Jinja template.
        """
        raise NotImplementedError()


    def batch_recurrent_states(self):
        raise NotImplementedError()


    def check_compat(self):
        """
        Decide if any model-specific requirements are met when creating Model
        """
        pass
