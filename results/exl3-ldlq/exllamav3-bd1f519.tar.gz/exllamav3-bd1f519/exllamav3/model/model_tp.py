from __future__ import annotations
import multiprocessing
import torch
from multiprocessing import Process, Pipe
from multiprocessing.reduction import ForkingPickler
from ..util import find_free_port
from .model_tp_alloc import TPAllocator
import os
from typing import Callable
from ..util.memory import touch_device_measure_vram
from ..util.progress import ProgressBar
from .config import Config
from ..util.misc import Cleanupper
from .model_tp_fn import *
import uuid
from ..util import log_tp, global_t0
from ..tokenizer.mm_embedding import send_embeddings


def _find_raw_tensor(obj, path = "args"):
    """
    Path of the first torch tensor inside a command's argument containers, or None. Tensors must reach the
    workers through the shared arena: a tensor pickled over the pipe becomes a torch shared-memory segment whose
    per-pickle refcount is unbalanced across several receiving ranks, so a rank that opens it late finds it
    unlinked (issue #530). Raising here names the offending parameter instead of crashing a straggler rank.
    """
    if isinstance(obj, torch.Tensor):
        return path
    if isinstance(obj, dict):
        for k, v in obj.items():
            r = _find_raw_tensor(v, f"{path}[{k!r}]")
            if r is not None:
                return r
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            r = _find_raw_tensor(v, f"{path}[{i}]")
            if r is not None:
                return r
    return None


def _check_command(fn, args):
    path = _find_raw_tensor(args)
    if path is not None:
        raise TypeError(
            f"Tensor-parallel command {getattr(fn, '__name__', fn)} would pickle a raw tensor at {path}; tensors "
            f"sent to TP workers must go through the shared arena (SMProducer.send)"
        )

cleanupper = Cleanupper()
DISPATCH_TIMEOUT = 20

class Model_TPMixin:

    def __init__(self):
        self.mp_children = []
        self.mp_parent_conn = []
        self.mp_child_conn = []
        self.loaded_tp = False
        self.tp_output_device = None
        self.tp_producer = None
        self.tp_backend = None
        # Devices whose per-forward None acks are still in flight (see forward_tp), and a strong
        # reference to the dispatched args for that pass: pickling CPU tensors (e.g. exported
        # recurrent-state handles) moves their storages into torch shared-memory segments that
        # only live as long as the sender-side objects, and the children may not have read the
        # command yet when forward_tp returns
        self.tp_pending_acks = []
        self.tp_pending_refs = None

    def create_tp_context(self, tp_backend: str):
        """
        Create the tensor-parallel worker context.

        TP runs one Python process per participating CUDA device so each worker can own its CUDA context, loaded
        module shards and cache tensors independently. The selected output device is represented in the parent
        process by pseudo pipe/process objects, while the remaining devices are spawned with multiprocessing Pipes
        for command dispatch. A final CPU worker slot uses device -1 for backend helper work such as native
        CPU-based reductions. All workers receive the same backend description and shared-memory producer metadata,
        allowing large tensors and collectives to move through shared memory instead of being pickled over pipes.

        The output device is the TP "master" for this process: it runs synchronously in the main process through
        PseudoParentConn instead of in a spawned worker. _load_tp() keeps that device last in active_devices so
        fan-out dispatch reaches spawned workers before invoking the blocking pseudo-worker path.
        """
        log_tp(None, "Creating TP context")

        # Must use spawn method to avoid CUDA errors. Docs say this should always be set by __main__ but seems
        # to work okay here
        multiprocessing.set_start_method("spawn", force = True)
        torch.multiprocessing.set_sharing_strategy("file_system")

        # Backend args
        self.tp_backend = tp_backend
        master_addr = os.environ.get("EXLLAMA_MASTER_ADDR", "127.0.0.1")
        master_port = os.environ.get("EXLLAMA_MASTER_PORT", find_free_port())
        match tp_backend:
            case "nccl":
                # Master address and port for the process group
                backend_args = {
                    "type": tp_backend,
                    "init_method": f"tcp://{master_addr}:{master_port}",
                    "uuid": uuid.uuid4().hex,
                }
            case "native":
                backend_args = {
                    "type": tp_backend,
                    "init_method": f"tcp://{master_addr}:{master_port}",
                    "uuid": uuid.uuid4().hex,
                }
            case _:
                raise ValueError(f"Unkwown backend type: {tp_backend}")

        # Spawn child processes, each running the mp_model_worker function
        num_devices = max(self.active_devices) + 1
        assert not self.mp_children
        assert not self.mp_parent_conn
        assert not self.mp_child_conn
        self.mp_children: list = [None] * (num_devices + 1)
        self.mp_parent_conn: list = [None] * (num_devices + 1)
        self.mp_child_conn: list = [None] * (num_devices + 1)
        self.tp_producer = SMProducer(buffer_size = 64 * 1024**2)

        for rank, device in enumerate(self.active_devices + [-1]):
            log_tp(None, f"Spawning child process: {device}")
            if self.tp_output_device == device:
                self.mp_parent_conn[device] = PseudoParentConn(
                    device,
                    self.active_devices,
                    self.tp_output_device,
                    backend_args,
                    self.tp_producer,
                    global_t0
                )
                self.mp_child_conn[device] = PseudoChildConn()
                self.mp_children[device] = PseudoChild()
            else:
                self.mp_parent_conn[device], self.mp_child_conn[device] = Pipe()
                self.mp_children[device] = Process(
                    target = mp_model_worker, args = (
                        self.mp_child_conn[device],
                        device,
                        self.active_devices,
                        self.tp_output_device,
                        backend_args,
                        self.tp_producer.export(),
                        global_t0
                    )
                )
                self.mp_children[device].start()

        # Install exit hook to avoid child processes hanging if main process exits before unloading model
        cleanupper.register_atexit(self.destroy_tp_context)

        log_tp(None, "TP context created")


    def destroy_tp_context(self):
        """
        Destroy child processes (when unloading TP model or atexit)
        """
        log_tp(None, "Destroying TP context")

        # Collect any deferred forward acks so quit commands aren't interleaved with stale results
        try:
            self.tp_drain_acks()
        except Exception:
            log_tp(None, "Exception draining deferred acks during destroy")

        # Destroy process group in child processes
        for device, (parent_conn, child) in \
                zip(list(range(len(self.mp_parent_conn))) + [-1], zip(self.mp_parent_conn, self.mp_children)):
            if device == self.tp_output_device or child is None:
                continue
            if child.is_alive():
                try:
                    log_tp(device, f"Closing backend, device {device}")
                    parent_conn.send("quit")
                except Exception:
                    log_tp(device, f"Exception while closing backend, device {device}")
                    pass

        # Destroy process group in main process. Called last since it blocks the main process
        self.mp_parent_conn[self.tp_output_device].quit()

        # Join child processes (terminate if hung), close connections
        for device, (parent_conn, child_conn, child) in \
            enumerate(zip(self.mp_parent_conn, self.mp_child_conn, self.mp_children)):
            if device == self.tp_output_device or child is None:
                continue
            log_tp(None, f"Attempting to destroy child, device {device}")
            child.join(timeout = 2)
            if child.is_alive():
                log_tp(None, f"Terminating child, device {device}")
                child.terminate()
            child_conn.close()
            parent_conn.close()
            log_tp(None, f"Closed connections, device {device}")

        self.mp_children = []
        self.mp_parent_conn = []
        self.mp_child_conn = []

        self.tp_producer.close()
        self.tp_producer = None

        # Unregister exit hook
        cleanupper.unregister_atexit(self.destroy_tp_context)
        log_tp(None, "Destroyed TP context")


    def tp_drain_acks(self):
        """
        Collect deferred per-forward acks from child workers before touching the pipes or the shared
        input arena again. forward_tp/prefill_tp leave the child ranks' end-of-pass None results in
        flight so the main process can launch sampling work on the output device while the children
        finish their module walks; the acks must be in before the next dispatch reuses the pipes and
        before prepare_inputs_for_tp resets the arena the stragglers may still be reading from.
        Child exceptions from the deferred pass surface here.
        """
        pending, self.tp_pending_acks = self.tp_pending_acks, []
        for device in pending:
            r = self.tp_worker_result(device)
            assert r is None, "TP logic error"
        # All children have consumed the deferred pass's command; shared storages may be released
        self.tp_pending_refs = None


    def tp_worker_dispatch_single(self, device, fn, args):
        """
        Dispatch single function call to child and get return value
        """
        self.tp_drain_acks()
        conn = self.mp_parent_conn[device]
        if not isinstance(conn, PseudoParentConn):
            _check_command(fn, args)
        conn.send((fn, args))
        if conn.poll(DISPATCH_TIMEOUT):
            result = conn.recv()
        else:
            raise TimeoutError("Timed out waiting for worker")
        if isinstance(result, Exception):
            raise result
        return result


    def tp_worker_dispatch(self, device, fn, args):
        """
        Dispatch function call to child
        """
        self.tp_drain_acks()
        conn = self.mp_parent_conn[device]
        if not isinstance(conn, PseudoParentConn):
            _check_command(fn, args)
        conn.send((fn, args))


    def tp_worker_result(self, device):
        """
        Await and return result from child function, and propagate any exceptions to main process
        """
        conn = self.mp_parent_conn[device]
        if conn.poll(DISPATCH_TIMEOUT):
            result = conn.recv()
        else:
            raise TimeoutError("Timed out waiting for worker")
        if isinstance(result, Exception):
            raise result
        return result


    def tp_worker_dispatch_multi(self, active_devices: list[int], fn, args, dev_args: list | None = None):
        """
        Dispatch one function call to multiple workers without waiting for results.

        args are shared across devices; dev_args, when provided, supplies per-device argument suffixes matched by
        active_devices order. Callers normally pass self.active_devices, whose last entry is the in-process output
        device. That ordering matters because dispatching to the pseudo-worker executes the function immediately and
        can block on TP collectives; spawned workers must already have received the same command before that happens.
        """
        self.tp_drain_acks()
        for idx, device in enumerate(active_devices):
            d_args = args
            if dev_args is not None:
                d_args = d_args + dev_args[idx]
            conn = self.mp_parent_conn[device]
            if not isinstance(conn, PseudoParentConn):
                _check_command(fn, d_args)
            conn.send((fn, d_args))


    def tp_worker_wait_multi(self, active_devices: list[int]):
        """
        Wait for a previously dispatched multi-worker call and return results in device order.

        With the standard self.active_devices ordering this waits on child-process results before the in-process
        output device result. This mirrors dispatch order and avoids treating the synchronous pseudo-worker as an
        early rendezvous point while child workers are still undispatched or unread.
        """
        r = []
        for device in active_devices:
            r.append(self.tp_worker_result(device))
        return r


    def tp_worker_dispatch_wait_multi(self, active_devices: list[int], fn, args, dev_args: list | None = None):
        """
        Dispatch a function to multiple workers and wait for all corresponding results.

        For TP-wide calls, pass devices in self.active_devices order so the output-device pseudo-worker remains
        last for both dispatch and result collection.
        """
        self.tp_worker_dispatch_multi(active_devices, fn, args, dev_args)
        return self.tp_worker_wait_multi(active_devices)


    def tp_cache_page_copy(self, cache_id: int, from_page: int, to_page: int, num_tokens: int):
        # active_devices is ordered with the output-device pseudo-worker last, so all spawned workers receive the
        # copy command before the main process enters the synchronous pseudo-worker call.
        for device in self.active_devices:
            self.tp_worker_dispatch(device, mp_cache_page_copy, (
                cache_id,
                from_page,
                to_page,
                num_tokens
            ))
        for device in self.active_devices:
            self.tp_worker_result(device)


    def tp_cpu_cache_init(self, cache_ids: list[int], max_slots: int = 0):
        """
        Size of one whole cache page across every rank, in bytes, allocating each rank's slot pool if max_slots
        is given. Called once with max_slots = 0 to size a slot, then again once the budget is divided up.
        """
        sizes = self.tp_worker_dispatch_wait_multi(
            self.active_devices,
            mp_cpu_cache_init,
            (cache_ids, max_slots)
        )
        return sum(sizes)


    def tp_cpu_cache_store(self, cache_ids: list[int], slot: int, page_index: int):
        """
        Copy a cache page out to system RAM on every rank, stored under slot
        """
        self.tp_dispatch_all(mp_cpu_cache_store, (cache_ids, slot, page_index))


    def tp_cpu_cache_fetch(self, cache_ids: list[int], slot: int, page_index: int):
        """
        Copy a stored cache page back into a page slot on every rank
        """
        self.tp_dispatch_all(mp_cpu_cache_fetch, (cache_ids, slot, page_index))


    def tp_dispatch_all(self, func, args):
        """
        Run the same worker function on every active TP device and require all workers to complete.

        self.active_devices keeps the output device last. Since that device is executed synchronously in the main
        process, this order gives child workers a chance to enter any collective/barrier before the main process
        does.
        """
        for device in self.active_devices:
            self.tp_worker_dispatch(device, func, args)
        for device in self.active_devices:
            self.tp_worker_result(device)


    def tp_dispatch_master(self, func, args):
        """
        Run a worker function only on the TP output device and return its result.
        """
        self.tp_worker_dispatch(self.tp_output_device, func, args)
        r = self.tp_worker_result(self.tp_output_device)
        return r


    def tp_dispatch_lm_head_argmax(self, args, return_max: bool = False):
        """
        Compute argmax over a tensor-parallel sharded LM head.

        Each device that owns a non-empty LM-head slice computes local maximum values and vocabulary indices for
        its shard. The partial maxima are gathered to the output device, where the final winner is selected and the
        global token index is returned. With return_max, the winning logit value comes back alongside (the same
        value the layer-split path exports as draft confidence); it is already on the output device from the
        gather, so this adds no transfer or synchronization.

        Dispatch follows self.active_devices order so the output-device pseudo-worker, if participating, runs after
        the spawned workers have been sent their local argmax command.
        """
        ad = {}
        for device in self.active_devices:
            a, b, _ = self.plan[device]["lm_head"]
            if b > a:
                ad[device] = a

        if len(ad) == 1 and self.tp_output_device in ad:
            v, i = self.tp_worker_dispatch_single(
                self.tp_output_device,
                mp_model_forward_lm_head_argmax,
                args + (ad[self.tp_output_device], None, None, self.config.vocab_size)
            )
            return (i, v) if return_max else i

        gd = sorted(set(ad.keys()) | {self.tp_output_device})
        ldims = [1 if d in ad else 0 for d in gd]

        dispatched = []
        for device in self.active_devices:
            if device in gd:
                self.tp_worker_dispatch(
                    device,
                    mp_model_forward_lm_head_argmax,
                    args + (ad.get(device, -1), gd, ldims, self.config.vocab_size)
                )
                dispatched.append(device)

        results = []
        for device in dispatched:
            r = self.tp_worker_result(device)
            if r is not None:
                results.append((device, r))

        assert len(results) == 1 and results[0][0] == self.tp_output_device, \
            "TP logic error"

        device = self.tp_output_device
        vals, inds = [], []
        all_vals, all_inds = results[0][1]
        p = 0
        for d, ldim in zip(gd, ldims):
            if d in ad:
                vals.append(all_vals[..., p].to(device))
                inds.append(all_inds[..., p].to(device))
            p += ldim
        vals = torch.stack(vals, dim = -1)
        inds = torch.stack(inds, dim = -1)
        winner = vals.argmax(dim = -1, keepdim = True)
        argmax = inds.gather(-1, winner).squeeze(-1)
        if return_max:
            return argmax, vals.gather(-1, winner).squeeze(-1)
        return argmax


    def tp_dispatch_lm_head_topk(self, args, top_k: int, scale: float = 1.0, softcap: float = 0.0):
        """
        Per-row top-k over a tensor-parallel sharded LM head, for drafters that need more than the argmax
        (DFlash2's selector walks the top-k candidates). Each shard takes its local top-k, scaled and
        softcapped as the selector would, the k candidates per shard are gathered to the output device
        (k values and k ids per shard, the same small gather as the argmax partials) and merged there to the
        global top-k. Returns (scores, ids) of shape (..., top_k), unsorted, on the output device.

        Dispatch follows self.active_devices order so the output-device pseudo-worker, if participating,
        runs after the spawned workers have been sent their command.
        """
        head_key = self.modules[self.logit_layer_idx].key
        ad = {}
        for device in self.active_devices:
            a, b, _ = self.plan[device][head_key]
            if b > a:
                ad[device] = a
        vocab = self.config.vocab_size

        if len(ad) == 1 and self.tp_output_device in ad:
            return self.tp_worker_dispatch_single(
                self.tp_output_device,
                mp_model_forward_lm_head_topk,
                args + (ad[self.tp_output_device], None, None, vocab, top_k, scale, softcap)
            )

        gd = sorted(set(ad.keys()) | {self.tp_output_device})
        ldims = [top_k if d in ad else 0 for d in gd]

        dispatched = []
        for device in self.active_devices:
            if device in gd:
                self.tp_worker_dispatch(
                    device,
                    mp_model_forward_lm_head_topk,
                    args + (ad.get(device, -1), gd, ldims, vocab, top_k, scale, softcap)
                )
                dispatched.append(device)

        out = None
        for device in dispatched:
            r = self.tp_worker_result(device)
            if device == self.tp_output_device:
                out = r
        assert out is not None, "TP logic error"
        all_v, all_i = out
        v, idx = torch.topk(all_v, top_k, dim = -1, sorted = False)
        return v, all_i.gather(-1, idx)


    # def tp_dispatch_lm_head_argmax_old(self, args):
    #     ad = []
    #     for device in self.active_devices:
    #         a, b, _ = self.plan[device]["lm_head"]
    #         if b > a:
    #             self.tp_worker_dispatch(device, mp_model_forward_lm_head_argmax_old, args + (a,))
    #             ad.append(device)
    #     results = []
    #     for device in ad:
    #         r = self.tp_worker_result(device)
    #         results.append((device, r))
    #
    #     device = self.tp_output_device
    #     vals, inds = [], []
    #     for (_, result) in sorted(results):
    #         v, i = result
    #         vals.append(v.to(device))
    #         inds.append(i.to(device))
    #     vals = torch.stack(vals, dim = -1)
    #     inds = torch.stack(inds, dim = -1)
    #     winner = vals.argmax(dim = -1)
    #     argmax = inds.gather(-1, winner.unsqueeze(-1)).squeeze(-1)
    #     return argmax


    def _load_tp(
        self,
        progressbar: bool,
        reserve_per_device: list[int] | None,
        use_per_device: list[int] | None,
        active_devices: list[int],
        max_chunk_size: int,
        max_output_size: int,
        max_output_factor: int,
        callback_sync: Callable[[int, int], None],
        generator: bool,
        tp_output_device: torch.device | int | str,
        config: Config,
        modules: list,
        dev_limits: dict | None,
        tp_backend: str,
        verbose: bool,
        tp_options: dict,
    ):
        assert use_per_device is None or reserve_per_device is None
        if dev_limits is None: dev_limits = {}

        # Set output device
        if tp_output_device is None:
            tp_output_device = active_devices[0]
        self.tp_output_device = torch.device(tp_output_device).index

        # Move output device to end of active device list. This device is the TP "master" running synchronously in
        # the main process via PseudoParentConn, so keeping it last prevents fan-out helpers from blocking in the
        # main process before child workers have received their commands.
        active_devices.remove(self.tp_output_device)
        active_devices.append(self.tp_output_device)

        # Fix a TP crash on gfx1100: a loading thread's first CUDA call, made mid-load,
        # can hang the ROCm runtime (no PCIe atomics). Warm the thread's per-device state up front,
        # leaving the current device as it was
        torch.cuda.init()
        current = torch.cuda.current_device()
        for d in active_devices:
            torch.cuda.set_device(d)
            w = torch.zeros(1, device = torch.device("cuda", d))
            torch.cuda.synchronize(d)
            del w
        torch.cuda.set_device(current)

        # Create TP context
        self.active_devices = active_devices
        self.create_tp_context(tp_backend)

        # Split model
        num_devices = max(self.active_devices) + 1
        max_mem = [0] * num_devices
        free_total = self.tp_worker_dispatch_wait_multi(self.active_devices, touch_device_measure_vram, ())
        for device, (free, total) in zip(self.active_devices, free_total):
            # print(free / 1024**3)  snip
            if reserve_per_device is not None:
                free -= reserve_per_device[device]
            if use_per_device is not None:
                free = use_per_device[device]
            max_mem[device] = free

        # Define TP split
        components = []
        for m in modules:
            components += m.make_tp_allocation(tp_options)
        allocator = TPAllocator(
            components,
            num_tokens = max_chunk_size,
            output_num_tokens = max_output_size,
            dev_limits = dev_limits,
        )
        allocator.initial_split(max_mem)
        if verbose:
            allocator.print_split()
        self.plan = allocator.compile_tp_plan()
        self.tp_worker_dispatch_wait_multi(self.active_devices, mp_set_plan, (self.plan, self.active_devices))

        # Distribution pipeline
        producer = SMProducer()
        self.tp_worker_dispatch_wait_multi(
            self.active_devices,
            mp_set_consumer,
            (),
            [(producer.export(),) if d != tp_output_device else (producer,) for d in active_devices]
        )

        # Begin loading modules
        with (ProgressBar(f"Loading (TP)" if progressbar else None, len(modules)) as progress):
            for idx, module in enumerate(modules):
                last_module = module

                if callback_sync: callback_sync(idx, len(modules))
                if generator: yield idx, len(modules)

                # Load module to CPU
                defer = module.can_defer_load()
                if defer:
                    config.stc.begin_deferred_load()
                module.load(torch.device("cpu"))
                if defer:
                    config.stc.end_deferred_load()

                # Do module-specific device/process split
                exported = module.tp_export(self.plan, producer)
                self.tp_worker_dispatch_wait_multi(self.active_devices, mp_model_append, (exported,))
                producer.clear()

                # Release loaded module
                module.unload()

                # Progress and callbacks per fully loaded module
                progress.update(idx + 1)

            # Append final gather layer
            if last_module.caps.get("logits_output"):
                self.tp_worker_dispatch_wait_multi(self.active_devices, mp_model_append_gather, ())

            # Final callback, 100% loaded
            if callback_sync: callback_sync(len(modules), len(modules))
            if generator: yield len(modules), len(modules)

        # Distribution pipeline
        self.tp_worker_dispatch_wait_multi(self.active_devices, mp_close_consumer, ())
        producer.close()

        config.stc.close()
        self.loaded_tp = True

        if 'yield' in locals():
            yield


    def unload_tp(self):
        if not self.loaded_tp:
            return
        self.destroy_tp_context()
        self.loaded_tp = False
        self.tp_output_device = None
        cleanupper.unregister_atexit(self.destroy_tp_context)


    def prepare_inputs_for_tp(self, x: torch.Tensor, params: dict) -> torch.Tensor:
        self.tp_producer.clear()
        # Use ID of Cache object as reference to avoid having to pickle it
        reserve = {}
        if "cache" in params:
            params["cache"] = id(params["cache"])
        # Share memory of any additional CPU tensors. Everything tensor-shaped must go through
        # the arena: CPU tensors pickled over the pipes become torch shared-memory segments with
        # fragile cross-process lifetimes (the recurrent_slots tensor used to crash GDN models
        # this way once forward acks became deferred)
        for tensor_param in [
            "block_table",
            "cache_seqlens",
            "positions",
            "position_ids",
            "recurrent_slots",
            "recurrent_slots_scan",
            "recurrent_slots_scan_in",
            "inv_freq",
            "input_ids",     # hash-MoE routing (DeepSeek-V4 bootstrap layers)
        ]:
            p = params.get(tensor_param)
            if p is not None:
                params[tensor_param] = self.tp_producer.send(p)

        p = params.get("indexed_embeddings")
        if p is not None:
            params["indexed_embeddings"] = send_embeddings(self.tp_producer, p)

        p = params.get("recurrent_states")
        if p is not None:
            reserve["recurrent_states"] = params["recurrent_states"]
            params["recurrent_states"] = [(rs.tp_export() if rs is not None else None) for rs in p]

        return self.tp_producer.send(x), reserve


    def restore_tp_params(self, params: dict, reserve: dict):
        # Read back state the forward pass wrote into the exported recurrent-state handles (the
        # output device's pseudo worker runs in this process, so its mutations are visible), then
        # restore the reserved originals
        exported_rs = params.get("recurrent_states")
        params.update(reserve)
        if "recurrent_states" in reserve and exported_rs is not None:
            for exp, orig in zip(exported_rs, reserve["recurrent_states"]):
                if exp is not None and orig is not None and hasattr(orig, "tp_readback"):
                    orig.tp_readback(exp)


    def prefill_tp(
        self,
        x: torch.Tensor,
        params: dict,
        last_kv_module_idx: int,
        modules: list,
    ):
        self.tp_worker_dispatch(-1, mp_cpu_reduce, ())

        x, reserve = self.prepare_inputs_for_tp(x, params)
        # active_devices order sends work to spawned CUDA workers first and the main-process output device last.
        # mp_model_forward enters backend barriers, so dispatching the synchronous pseudo-worker early would block
        # before the other ranks had even received this forward command. Child ranks all receive the same
        # command, pickled once and sent as raw bytes (Connection.send is dumps + send_bytes, so this is
        # wire-identical) — per-rank pickling of the params dict was part of the dispatch stagger.
        args = (x, params, last_kv_module_idx, True, None)
        _check_command(mp_model_forward, args)
        msg = ForkingPickler.dumps((mp_model_forward, args))
        for device in self.active_devices:
            if device == self.tp_output_device:
                self.tp_worker_dispatch(device, mp_model_forward, args)
            else:
                self.mp_parent_conn[device].send_bytes(msg)
        # Same deferred-ack scheme as forward_tp: only the inline pseudo-worker's result is
        # consumed here, child acks drain at the next dispatch
        r = self.tp_worker_result(self.tp_output_device)
        assert r is None, "TP logic error"
        self.tp_pending_acks = [d for d in self.active_devices if d != self.tp_output_device]
        self.tp_pending_acks.append(-1)
        # See forward_tp: the exported recurrent-state handles must outlive the deferred acks
        self.tp_pending_refs = (args, params.get("recurrent_states"))
        self.restore_tp_params(params, reserve)
        return None


    def forward_tp(
        self,
        x: torch.Tensor,
        params: dict,
        last_kv_module_idx: int,
        modules: list,
    ):
        # Warmup passes run without collectives (see Model.warmup), so the CPU reduce helper
        # stays out of it: it would sit waiting for reduce jobs nobody pushes
        warmup = bool(params.get("tp_warmup"))
        if not warmup:
            self.tp_worker_dispatch(-1, mp_cpu_reduce, ())

        x, reserve = self.prepare_inputs_for_tp(x, params)
        # Keep the output-device pseudo-worker last for the same reason as prefill_tp(): its send() path executes
        # immediately in the main process and may block inside TP collectives until child workers arrive.
        # Shared pre-pickled command bytes for child ranks, as in prefill_tp
        args = (x, params, last_kv_module_idx, False, None)
        _check_command(mp_model_forward, args)
        msg = ForkingPickler.dumps((mp_model_forward, args))
        for device in self.active_devices:
            if device == self.tp_output_device:
                self.tp_worker_dispatch(device, mp_model_forward, args)
            else:
                self.mp_parent_conn[device].send_bytes(msg)
        # The output-device pseudo-worker ran inline during the dispatch loop above, so its result
        # is already buffered. The child ranks' None acks (and the CPU helper's) are left in flight
        # and drained at the next dispatch, letting the caller queue sampling work on the output
        # device while the child processes finish their module walks
        out = self.tp_worker_result(self.tp_output_device)
        assert out is not None, "TP logic error"
        self.tp_pending_acks = [d for d in self.active_devices if d != self.tp_output_device]
        if not warmup:
            self.tp_pending_acks.append(-1)
        # Pin the exported recurrent-state handles too: restore_tp_params swaps them out of the
        # params dict in place, so holding args alone would not keep their shared storages alive
        self.tp_pending_refs = (args, params.get("recurrent_states"))
        self.restore_tp_params(params, reserve)
        return out


    def tp_rotate_cache_pages(self, cache_id: int, all_rotations: torch.Tensor):
        all_rotations = self.tp_producer.send(all_rotations)
        self.tp_worker_dispatch_wait_multi(self.active_devices, mp_rotate_cache_pages, (
            cache_id,
            all_rotations
        ))
